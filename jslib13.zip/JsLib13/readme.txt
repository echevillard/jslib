JsLib 1.3 - readme.txt - 23/02/2005
_______________________________________________________________________________

Table of contents

1. Description
2. Installation
3. Usage
4. Software license
5. Support
_______________________________________________________________________________

1. Description

Project: JsLib
Version: 1.3
Type: source code library
Language: JavaScript 1.3

JsLib is a French-written library of JavaScript functions. Its goal is to
make easier the task of the developer in two manners:
    - by placing at his disposal all the functions which he can need during
    the development for a dynamic Web site;
    - by masking completely the compatibility problems between the main Web
    browsers on the market.

JavaScript is a light and interpreted programming language, with rudimentary
object-oriented functionalities. The general kernel of the language has been
embedded in Netscape Navigator and others Web browsers, and optimized for Web
programming with addition of objects which represent the window of the browser
and its contents.

This "client-side" version of JavaScript makes it possible to include 
"executable contents" in a Web page; this means that a Web page is not only
made up of static HTML code, but can include dynamic programs which interact
with the user, monitor the browser and create HTML contents without reloading
the page.

JsLib functions are gathered according to their application in several files:
    chrono.js       Simulates a stop watch and displays the elapsed time.
    clavier.js      Catches and manages the keyboard's events.
    cookies.js      Reads, writes and deletes current Web page's cookies. 
    crypto.js       Encrypts/decrypts (AES) and checks the integrity (MD5) of
                    data.
    date.js         Formats the current date and the "last modified" date of
                    the document. 
    dialogues.js    Displays and monitors the most used dialog boxes.
    dyna.js         Monitors divisions (or layers) on dynamic Web pages
                    (DHTML).
    fenetres.js     Modifies the properties and the contents of the browser's
                    windows.
    forms.js        Formats, verifies and recover the contents of HTML forms.
    heure.js        Formats the current hour and displays it in a static or
                    dynamic way.
    images.js       Monitors the load process and the display of pictures.
    langue.js       Detects the language used by the client's browser.
    liens.js        Inserts a link on a text, a picture, a button or a dynamic
                    picture.
    medias.js       Inserts an audio or video medium in the current Web page.
    monnaie.js      Computes the french VAT and amounts including all taxes,
                    and converts a currency into Euro.
    navig.js        Detects the browser, its version and the operating system
                    of the client.
    souris.js       Catches and manages the mouse's events.
    xml.js          Loads a XML file and permits to access to the data it
                    contains.

All the provided functions are in conformity with the ECMA-262 Standard
(JavaScript 1.3). They have been tested and validated with:
    * Internet Explorer 5.0, 5.5, 6.0
    * Firefox 1.0, Mozilla 1.7
    * Nestcape 6.x and 7.x
    * Opera 6.x and 7.x
    * Safari 1.x

Approximately 95% of the functions work fine with the past versions of these
browsers (Internet Explorer 4.0, Netscape 4.7, etc.) and with others browsers
partially ECMA-262 compliant (Galeon, Konqueror, OmniWeb, etc.).
_______________________________________________________________________________

2. Installation

To install JsLib on your computer, you just have to uncompress the file
(jslib13.zip or jslib13.tar.gz) in the directory of your choice.

Three sub-directories are then created:
    doc/            Documentation of the scripts in HTML format;
    exemples/       HTML pages with examples illustrating the operation of
                    JsLib functions;
    scripts/        JavaScript files of JsLib.

If you choose to use JsLib to develop a Web site, just copy the scripts/
directory in the root directory of your site.
_______________________________________________________________________________

3. Usage

The best way to understand the operating mode of JsLib is the following one:
    - read the documentation of the script of your choice in order to
    understand the role, the principle of operation and the syntax of each
    function;
    - open the example page of this script in a Web browser and test the way
    it runs;
    - open the example page of this script in a text editor and have a look at
    the integration of the script in the HTML code and its usage;
    - now it's your turn! 

As an example, here is the HTML code of a Web page which displays only the
current date :
    <HTML>
        <HEAD>
            <TITLE>Date du jour</TITLE>
            <!-- includes the JsLib file -->
            <SCRIPT LANGUAGE="JavaScript" SRC="date.js"></SCRIPT>
        </HEAD>
        <BODY>
            <!-- call the wanted JavaScript function -->
            <SCRIPT LANGUAGE="JavaScript">
                document.write(dateJour());
            </SCRIPT>
        </BODY>
    </HTML>
    
This page runs in any JavaScript/ECMAScript compliant browser, on the
condition of copying the file date.js in the same directory as the page.
_______________________________________________________________________________

4. Software license

JsLib 1.3
Copyright (C) 2001-2005 Etienne CHEVILLARD

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later
version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
_______________________________________________________________________________

5. Support

Mistakes, criticism, improvements, questions: all the comments are welcome.
Write to the author to this e-mail address:
echevillard(at)users.sourceforge.net

The last release of JsLib is available on SourceForge:
http://jslib.sourceforge.net/
_______________________________________________________________________________
