/* date.js
 * Role : formate la date du jour et la date de modification du document
 * Projet: JsLib
 * Auteur : Etienne CHEVILLARD (echevillard@yahoo.fr)
 * Version  : 1.1
 * Creation : 22/04/2001
 * Mise a jour : 21/03/2002
 */

// --- Code interprete au chargement ---

// ignore les erreurs
window.onerror = function () {
	return true;
}

// definit un tableau pour les jours de la semaine
var date_jours = new Array(7);
date_jours[0] = "Dimanche";
date_jours[1] = "Lundi";
date_jours[2] = "Mardi";
date_jours[3] = "Mercredi";
date_jours[4] = "Jeudi";
date_jours[5] = "Vendredi";
date_jours[6] = "Samedi";
// definit un tableau pour les mois de l'annee
var date_mois = new Array(12);
date_mois[0] = "janvier";
date_mois[1] = "f&eacute;vrier";
date_mois[2] = "mars";
date_mois[3] = "avril";
date_mois[4] = "mai";
date_mois[5] = "juin";
date_mois[6] = "juillet";
date_mois[7] = "ao&ucirc;t";
date_mois[8] = "septembre";
date_mois[9] = "octobre";
date_mois[10] = "novembre";
date_mois[11] = "d&eacute;cembre";
// obtient la date de derniere modification du document
var date_der = new Date(document.lastModified);
// corrige une bogue de Netscape 4 (annee sur deux chiffres)
if ((date_der.getFullYear()+50) < (new Date()).getFullYear()) {
	date_der.setFullYear(parseInt(date_der.getFullYear()) + 100);
}
// corrige une bogue de HotJava 3 (non-construction de la date)
if (isNaN(date_der.getFullYear())) {
	if (navigator.userAgent.toLowerCase().indexOf("hotjava") != -1) {
		var date_derh = document.lastModified.length;
		var date_derm = document.lastModified.substring(4, 7);
		if (date_derm == "Jan") date_derm = 0;
		else if (date_derm == "Feb") date_derm = 1;
		else if (date_derm == "Mar") date_derm = 2;
		else if (date_derm == "Apr") date_derm = 3;
		else if (date_derm == "May") date_derm = 4;
		else if (date_derm == "Jun") date_derm = 5;
		else if (date_derm == "Jul") date_derm = 6;
		else if (date_derm == "Aug") date_derm = 7;
		else if (date_derm == "Sep") date_derm = 8;
		else if (date_derm == "Oct") date_derm = 9;	
		else if (date_derm == "Nov") date_derm = 10;
		else date_derm = 11;	 
		date_der = new Date(document.lastModified.substring(date_derh-4, date_derh),
							date_derm,
							document.lastModified.substring(8, 10));
	// si la date n'existe pas, recupere la date du jour
	} else {
		date_der = new Date();
	}
}

// --- Fonctions ---

// Retourne la date du jour en abrege, au format JJ/MM/AAAA
function dateJourAbr() {
	// obtient la date du jour
	var date_cour = new Date();
	// obtient le mois sur deux caracteres
	var date_m = parseInt(date_cour.getMonth()) + 1;
	if (date_m < 10) date_m = "0" + date_m;
	// retourne la date formatee	
	return (date_cour.getDate() + "/" + date_m + "/" + date_cour.getFullYear());
} // fin dateJourAbr()

// Retourne la date du jour au format JJ mmm AAAA
function dateJour() {
	// obtient la date du jour
	var date_cour = new Date();
	// rajoute "er" au jour si c'est le premier du mois
	var date_j = date_cour.getDate();
	if (date_j == "1") date_j = "1er";
	// obtient le mois en toutes lettres
	var date_m = date_cour.getMonth();
	date_m = date_mois[parseInt(date_m)];
	// retourne la date formatee	
	return (date_j + " " + date_m + " " + date_cour.getFullYear());
} // fin dateJour()

// Retourne la date du jour au format Jjj JJ mmm AAAA
function dateJourLng() {
	// obtient la date du jour
	var date_cour = new Date();
	// rajoute "er" au jour si c'est le premier du mois
	var date_j = date_cour.getDate();
	if (date_j == "1") date_j = "1er";
	// obtient le mois en toutes lettres
	var date_m = date_cour.getMonth();
	date_m = date_mois[parseInt(date_m)];	
	// obtient le jour de la semaine en toutes lettres
	var date_d = date_cour.getDay();
	date_d = date_jours[parseInt(date_d)];
	// retourne la date formatee	
	return (date_d + " " + date_j + " " + date_m + " " + date_cour.getFullYear());
} // fin dateJourLng()

// Retourne la date de derniere modification du document au format JJ/MM/AAAA
function dateModifAbr() {
	// obtient le mois sur deux caracteres
	var date_m = parseInt(date_der.getMonth()) + 1;
	if (date_m < 10) date_m = "0" + date_m;
	// retourne la date formatee	
	return (date_der.getDate() + "/" + date_m + "/" + date_der.getFullYear());
} // fin dateModifAbr()

// Retourne la date de derniere modification du document au format JJ mmm AAAA
function dateModif() {
	// rajoute "er" au jour si c'est le premier du mois
	var date_j = date_der.getDate();
	if (date_j == "1") date_j = "1er";
	// obtient le mois en toutes lettres
	var date_m = date_der.getMonth();
	date_m = date_mois[parseInt(date_m)];
	// retourne la date formatee	
	return (date_j + " " + date_m + " " + date_der.getFullYear());
} // fin dateModif()

// Retourne la date de derniere modification du document au format Jjj JJ mmm AAAA
function dateModifLng() {
	// obtient le jour de la semaine en toutes lettres
	var date_d = date_der.getDay();
	date_d = date_jours[parseInt(date_d)];
	// retourne la date formatee	
	return (date_d + " " + dateModif());
} // fin dateModifLng()
