/* dialogues.js
 * Role : affiche et controle les boites de dialogue les plus utilisees
 * Projet: JsLib
 * Auteur : Etienne CHEVILLARD (echevillard@yahoo.fr)
 * Version  : 1.0
 * Creation : 12/07/2001
 * Mise a jour : 28/07/2001
 * Bogues connues :	- le dialogue d'impression n'apparait pas sous Opera 5
 */

// --- Code interprete au chargement ---

// ignore les erreurs
window.onerror = function () {
	return true;
}

// --- Fonctions ---

// Affiche une boite de dialogue d'information
function dialogueInfo(message) {
	if (!message) { message = "Information"; }
	window.alert(message);
} // fin dialogueInfo(message)

// Affiche une boite de dialogue de confirmation et retourne la reponse choisie
function dialogueConfirm(message) {
	if (!message) { message = "Confirmation"; }
	return (window.confirm(message));
} // fin dialogueConfirm(message)

// Affiche une boite de dialogue de saisie et retourne le texte saisi
function dialogueSaisie(message, defaut) {
	var dialogues_rep;
	if (!message) { message = "Saisie"; }
	if (!defaut) { defaut = ""; }
	dialogues_rep = window.prompt(message, defaut);
	if (!dialogues_rep) { dialogues_rep = ""; }
	return (dialogues_rep);
} // fin dialogueSaisie(message, defaut)

// Affiche la boite de dialogue d'impression de la page Web courante
function dialogueImprimer() {
	if (window.print) {
		window.focus();
		window.print();
	} else {
		var dialogues_agt = navigator.userAgent.toLowerCase();
		if ((dialogues_agt.indexOf("msie") != -1) && (dialogues_agt.indexOf("opera") == -1)) {
			var dialogues_imp = "<OBJECT ID='WindowPrint' WIDTH=0 HEIGHT=0 CLASSID='CLSID:8856F961-340A-11D0-A96B-00C04FD705A2'></OBJECT>";
			document.body.insertAdjacentHTML("beforeEnd", dialogues_imp);
			WindowPrint.ExecWB(6, 2);
		}
	}
} // fin dialogueImprimer
