/* forms.js
 * Role : formate, controle et recupere le contenu des formulaires
 * Projet: JsLib
 * Auteur : Etienne CHEVILLARD (echevillard@yahoo.fr)
 * Version  : 1.0
 * Creation : 2/05/2001
 * Mise a jour : 27/08/2001
 */

// --- Code interprete au chargement ---

// ignore les erreurs
window.onerror = function () {
	return true;
}

// recupere les parametres de l'URL
if (window.location.search && (window.location.search.indexOf("=") != -1)) {
	var forms_par = (window.location.search.substring(1, window.location.search.length)).split("&");
	var forms_cle = new Array(forms_par.length);
	var forms_val = new Array(forms_par.length);
	for (var i=0; i<forms_par.length; i++) {
		forms_cle[i] = forms_par[i].substring(0, forms_par[i].indexOf("="));
		forms_val[i] = forms_par[i].substring(forms_par[i].indexOf("=")+1, forms_par[i].length); 
		forms_val[i] = unescape((forms_val[i].split("+")).join(" "));
	}
}

// --- Fonctions ---

// Supprime les espaces qui commencent ou qui terminent la chaine specifiee
function supprimerEspaces(chaine) {
	var forms_deb;
	var forms_fin;
	// enleve les espaces a gauche
	forms_deb = chaine;
	forms_fin = chaine;
	for(var i=0; ((i<forms_deb.length) && (forms_deb.charAt(i)==' ')); i++) {
		forms_fin = forms_fin.substring(1, forms_fin.length);
	}
	// enleve les espaces a droite
	forms_deb = forms_fin;
	for(var i=forms_deb.length-1; ((i>=0) && (forms_deb.charAt(i)==' ')); i--)
		forms_fin = forms_fin.substring(0, forms_fin.length-1);
	// retourne la chaine obtenue
	return (forms_fin);
} // fin supprimerEspaces(chaine)

// Verifie que la chaine specifiee n'est pas vide
function verifierPresence(chaine) {
	if (supprimerEspaces(chaine).length > 0) {
		return true;
	} else {
		return false;
	}	
} // fin verifierPresence(chaine)

// Verifie que l'adresse e-mail specifiee est valide
function verifierEmail(email) {
	var forms_adr;
	var forms_nom;
	var forms_arob;
	var forms_dom;
	var forms_point;
	var forms_ext;
	// verifie la presence d'une chaine
	if (! verifierPresence(email)) { return false; }
	// enleve les espaces superflus a gauche et a droite
	forms_adr = supprimerEspaces(email);
	// obtient et verifie la position de l'arobase 
	forms_arob = forms_adr.lastIndexOf("@");
	if (forms_arob != forms_adr.indexOf("@")) { return false; }
	// extrait et verifie le nom
	forms_nom = forms_adr.substring(0, forms_arob);
	if (forms_nom.length < 1) { return false; }
	// verifie le point entre le domaine et l'extension
	forms_point = forms_adr.lastIndexOf(".");
	if (forms_point < forms_arob) { return false; }
	// extrait et verifie l'extension
	forms_ext = forms_adr.substring(forms_point+1, forms_adr.length);
	if (forms_ext.length < 2) { return false; }
	// extrait et verifie le domaine
	forms_dom = forms_adr.substring(forms_arob+1, forms_point);
	if (forms_dom.length < 2) { return false; }
	return true;		
} // fin verifierEmail(email)

// Formate le contenu d'un champ de formulaire de type "Nom"
function formaterChampNom(champ) {
	var forms_nom;
	var forms_pos;
	// enleve les espaces superflus a gauche et a droite
	forms_nom = supprimerEspaces(champ.value);
	// enleve les espaces superflus au milieu
	for(var i=0; i<forms_nom.length-1; i++) {
		while ((forms_nom.charAt(i) == ' ') && (forms_nom.charAt(i+1) == ' ')) { 
			forms_nom = forms_nom.substring(0, i)
				+ forms_nom.substring(i+1, forms_nom.length); 
		}
	}
	// met la premiere lettre du nom en majuscule
	forms_nom = forms_nom.substring(0, 1).toUpperCase()
		+ forms_nom.substring(1, forms_nom.length).toLowerCase();
	// met la premiere lettre de chaque mot en majuscule
	for(var i=0; i<forms_nom.length-1; i++) {
		if ((forms_nom.charAt(i) == '-') || (forms_nom.charAt(i) == ' ')) {
			forms_nom = forms_nom.substring(0, i) + forms_nom.charAt(i)
				+ forms_nom.substring(i+1, i+2).toUpperCase() 
				+ forms_nom.substring(i+2, forms_nom.length);
		}
	} 
	// met a jour le champ
	champ.value = forms_nom;
} // fin formaterChampNom(champ)

// Formate le contenu d'un champ de formulaire de type "Email"  
function formaterChampEmail(champ) {
	var forms_email;
	// convertit l'adresse en minuscules
	forms_email = (champ.value).toLowerCase();
	// supprime les eventuels < et >
	if (forms_email.charAt(0) == "<") { 
		forms_email = forms_email.substring(1, forms_email.length);
	}  
	if (forms_email.charAt(forms_email.length - 1) == ">") { 
		forms_email = forms_email.substring(0, forms_email.length-1);
	}  
	// enleve les espaces superflus
	for(var i=0; i<forms_email.length; i++) {
		while ((forms_email.charAt(i) == ' ')) { 
			forms_email = forms_email.substring(0, i)
				+ forms_email.substring(i+1, forms_email.length); 
		}
	}
	// met a jour le champ
	champ.value = forms_email;
} // fin formaterChampEmail(champ)

// Verifie que le formulaire specifie est rempli puis l'expedie
function envoyerFormulaire(formulaire) {
	// verifie que tous les champs du formulaire sont remplis
	for (var i=0; i<formulaire.elements.length; i++) {
		if (! verifierPresence(formulaire.elements[i].value)) {
			alert("Erreur : le champ \"" + formulaire.elements[i].name + "\" est vide.");
			formulaire.elements[i].focus();
			return false;
		}
	}
	// expedie le formulaire
	formulaire.submit();
} // fin envoyerFormulaire(formulaire) 

// Retourne le nombre de parametres contenus dans l'URL de la page
function nombreParametres() {
	if (window.location.search) {
		return (forms_cle.length);
	} else {
		return (0);
	}
} // fin nombreParametres()

// Retourne la valeur du parametre correspondant a la cle indiquee
function valeurParametre(cle) {
	if (window.location.search) {
		for (var i=0; i<forms_cle.length; i++) {
			if (forms_cle[i].toLowerCase() == supprimerEspaces(cle).toLowerCase()) {
				return (forms_val[i]);
			}
		}		
	} else {
		return ("");
	}
} // fin valeurParametre()