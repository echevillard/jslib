/* cookies.js
 * Role : lit, ecrit et efface les cookies de la page Web courante
 * Projet: JsLib
 * Auteur : Etienne CHEVILLARD (echevillard@yahoo.fr)
 * Version  : 1.0
 * Creation : 11/04/2001
 * Mise a jour : 20/04/2001
 */

// --- Code interprete au chargement ---

// ignore les erreurs
window.onerror = function () {
	return true;
}

// verifie que le navigateur accepte les cookies
var cookies_ok = false;
if (navigator.cookieEnabled) {
	cookies_ok = true;
} else {
	ecrireCookie ("jslib", "ok");
	if (lireCookie("jslib") == "ok") {
		cookies_ok = true;
	}
	effacerCookie("essai");
} 

// --- Fonctions ---

// Indique si le navigateur accepte les cookies
function accepteCookies() {
	return (cookies_ok);
} // fin accepteCookies()

// Lit et retourne la valeur du cookie de nom specifie
function lireCookie(nom) {
	// nom "complet" du cookie
	var nomEq = nom + "=";
	// cree un tableau pour les cookies du document
	var tab = document.cookie.split(";");
	// parcoure le tableau 
	for(var i=0; i<tab.length; i++) {
		var cook = tab[i];
		// supprime les espaces inutiles
		while (cook.charAt(0) == ' ')
			cook = cook.substring(1, cook.length);
		// si le cookie est celui recherche, retourne sa valeur
		if (cook.indexOf(nomEq) == 0)
			return unescape(cook.substring(nomEq.length, cook.length));
	} // fin for(var i=0; i<tab.length; i++)
	// si pas de correspondance, retourne une chaine vide
	return ("");
} // fin lireCookie(nom)

// Ecrit un cookie de nom et valeur specifiees pour le nombre de jours specifie
function ecrireCookie(nom, valeur, jours) {
	var expire;
	// expiration au bout d'un certain nombre de jours
	if (jours) {
		var date = new Date();
		// convertit les jours en millisecondes pour creer la date d'expiration
		date.setTime(date.getTime() + (jours*24*60*60*1000));
		expire = "; expires=" + date.toGMTString();
	// expiration des l'arret du navigateur
	} else {
		expire = "";
	} // fin if (jours) 
	// ecrit le cookie
	document.cookie = nom + "=" + escape(valeur) + expire + "; path=/";
} // fin ecrireCookie(nom, valeur, jours)

// Efface le cookie de nom specifie
function effacerCookie(nom) {
	// re-ecrit le cookie avec une date d'expiration negative 
	ecrireCookie(nom, "", -1);
} // fin effacerCookie(nom)
