/* liens.js
 * Role : insere dans la page Web un lien sur un texte, un bouton ou une image
 * Projet: JsLib
 * Auteur : Etienne CHEVILLARD (echevillard@yahoo.fr)
 * Version  : 1.0
 * Creation : 30/04/2001
 * Mise a jour : 30/04/2001
 * Bogues connues :	- Opera 5 remplace les commentaires des liens par leurs URLs
 */

// --- Code interprete au chargement ---

// ignore les erreurs
window.onerror = function () {
	return true;
}

// variables communes
var liens_code;
var liens_cpt = 0;
	
// --- Fonctions ---

// Insere un lien vers une page Web sur un texte
function lienTexteWeb(texte, url, cible, commentaire) {
	// traite les arguments manquants
	if (! commentaire) { commentaire = ""; }
	if (! cible) { cible = "_self"; }
	// ecrit dans la page le code correspondant au lien
	liens_code = "<A HREF=\"" + url + "\" TARGET=\"" + cible + "\" onMouseOver=\"window.status='" + commentaire;
	liens_code += "'; return true;\" onMouseOut=\"window.status=''; return true;\">" + texte + "</A>";
	document.writeln(liens_code);
} // fin lienTexteWeb(texte, url, cible, commentaire)

// Insere un lien vers une adresse e-mail sur un texte
function lienTexteEmail(texte, email, sujet, commentaire) {
	// traite les arguments manquants
	if (! commentaire) { commentaire = ""; }
	if (! sujet) { sujet = ""; }
	// ecrit dans la page le code correspondant au lien
	liens_code = "<A HREF=\"mailto:" + email + "?subject=" + sujet + "\" onMouseOver=\"window.status='" + commentaire;
	liens_code += "'; return true;\" onMouseOut=\"window.status=''; return true;\">" + texte + "</A>";
	document.writeln(liens_code);
} // fin lienTexteEmail(texte, email, sujet, commentaire)

// Insere un lien vers une page Web sur une image
function lienImageWeb(image, url, cible, commentaire) {
	// traite les arguments manquants
	if (! commentaire) { commentaire = ""; }
	if (! cible) { cible = "_self"; }
	// ecrit dans la page le code correspondant au lien
	liens_code = "<A HREF=\"" + url + "\" TARGET=\"" + cible + "\" onMouseOver=\"window.status='" + commentaire;
	liens_code += "'; return true;\" onMouseOut=\"window.status=''; return true;\">";
	liens_code += "<IMG SRC=\"" + image + "\" BORDER=0 ALIGN=ABSMIDDLE ALT=\"" + commentaire + "\"></A>";
	document.writeln(liens_code);
} // fin lienImageWeb(image, url, cible, commentaire)

// Insere un lien vers une adresse e-mail sur une image
function lienImageEmail(image, email, sujet, commentaire) {
	// traite les arguments manquants
	if (! commentaire) { commentaire = ""; }
	if (! sujet) { sujet = ""; }
	// ecrit dans la page le code correspondant au lien
	liens_code = "<A HREF=\"mailto:" + email + "?subject=" + sujet + "\" onMouseOver=\"window.status='" + commentaire;
	liens_code += "'; return true;\" onMouseOut=\"window.status=''; return true;\">";
	liens_code += "<IMG SRC=\"" + image + "\" BORDER=0 ALIGN=ABSMIDDLE ALT=\"" + commentaire + "\"></A>";
	document.writeln(liens_code);
} // fin lienImageEmail(image, email, sujet, commentaire)

// Insere un lien vers une page Web sur un bouton
function lienBoutonWeb(texte, url, cible, commentaire) {
	var liens_dest;
	// traite les arguments manquants
	if (! commentaire) { commentaire = ""; }
	if (! cible) { cible = "_self"; }
	// obtient la notation Javascript de la cible 
	if (cible == "_self") { liens_dest = "self.location.href='" + url + "'"; }
	else if (cible == "_parent") { liens_dest = "parent.location.href='" + url + "'"; }
	else if (cible == "_top") { liens_dest = "top.location.href='" + url + "'"; }
	else { liens_dest = "window.open('" + url + "', '" + cible + "')"; }
	// ecrit dans la page le code correspondant au lien
	liens_code = "<FORM><INPUT TYPE=\"button\" VALUE=\"" + texte + "\" onClick=\"" + liens_dest;
	liens_code += ";\" onMouseOver=\"window.status='" + commentaire;
	liens_code += "'; return true;\" onMouseOut=\"window.status=''; return true;\"></FORM>";	
	document.writeln(liens_code);
} // fin lienBoutonWeb(texte, url, cible, commentaire)

// Insere un lien vers une adresse e-mail sur un bouton
function lienBoutonEmail(texte, email, sujet, commentaire) {
	// traite les arguments manquants
	if (! commentaire) { commentaire = ""; }
	if (! sujet) { sujet = ""; }
	// ecrit dans la page le code correspondant au lien
	liens_code = "<FORM><INPUT TYPE=\"button\" VALUE=\"" + texte + "\" onClick=\"window.location.href='mailto:";
	liens_code += email + "?subject=" + sujet + "';\" onMouseOver=\"window.status='" + commentaire;
	liens_code += "'; return true;\" onMouseOut=\"window.status=''; return true;\"></FORM>";
	document.writeln(liens_code);
} // fin lienBoutonEmail(texte, email, sujet, commentaire)

// Insere un lien vers une page Web sur une image dynamique
function lienDynaWeb(image_out, image_over, url, cible, commentaire) {
	// traite les arguments manquants
	if (! commentaire) { commentaire = ""; }
	if (! cible) { cible = "_self"; }
	// ecrit dans la page le code correspondant au lien
	liens_code = "<A HREF=\"" + url + "\" TARGET=\"" + cible + "\" onMouseOver=\"liens_image" + liens_cpt;
	liens_code += ".src='" + image_over + "'; window.status='" + commentaire + "'; return true;\" ";
	liens_code += " onMouseOut=\"liens_image" + liens_cpt + ".src='" + image_out + "'; window.status=''; return true;\">";
	liens_code += "<IMG NAME=\"liens_image" + liens_cpt + "\" SRC=\"" + image_out + "\" BORDER=0 ALIGN=ABSMIDDLE ";
	liens_code += "onLoad=\"liens_image_temp=new Image(0,0); liens_image_temp.src='" + image_over + "'; return true;\"></A>";
	document.writeln(liens_code);
	// incremente le compteur d'images
	liens_cpt = parseInt(liens_cpt) + 1;	
} // fin lienDynaWeb(image_out, image_over, url, cible, commentaire)

// Insere un lien vers vers une adresse e-mail sur une image dynamique
function lienDynaEmail(image_out, image_over, email, sujet, commentaire) {
	// traite les arguments manquants
	if (! commentaire) { commentaire = ""; }
	if (! sujet) { sujet = ""; }
	// ecrit dans la page le code correspondant au lien
	liens_code = "<A HREF=\"mailto:" + email + "?subject=" + sujet + "\" onMouseOver=\"liens_image" + liens_cpt;
	liens_code += ".src='" + image_over + "'; window.status='" + commentaire + "'; return true;\" ";
	liens_code += " onMouseOut=\"liens_image" + liens_cpt + ".src='" + image_out + "'; window.status=''; return true;\">";
	liens_code += "<IMG NAME=\"liens_image" + liens_cpt + "\" SRC=\"" + image_out + "\" BORDER=0 ALIGN=ABSMIDDLE ";
	liens_code += "onLoad=\"liens_image_temp=new Image(0,0); liens_image_temp.src='" + image_over + "'; return true;\"></A>";
	document.writeln(liens_code);
	// incremente le compteur d'images
	liens_cpt = parseInt(liens_cpt) + 1;	
} // fin lienDynaEmail(image_out, image_over, email, sujet, commentaire)
