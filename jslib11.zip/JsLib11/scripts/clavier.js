/* clavier.js
 * Role : capture et gere les evenements clavier
 * Projet: JsLib
 * Auteur : Etienne CHEVILLARD (echevillard@yahoo.fr)
 * Version  : 1.0
 * Creation : 28/07/2001
 * Mise a jour : 14/08/2001
 * Bogues connues : - la touche Alt est ignoree par Netscape Navigator 4 et Opera 5
 *					- Netscape Navigator 4 ignore certaines touches de fonction
 */

// --- Code interprete au chargement ---

// ignore les erreurs
window.onerror = function () {
	return true;
}

// corrige le code des touches
var clavier_un = -1;
var clavier_deux = -1;

// capture les evenements sous Netscape Navigator
if (document.layers) {
	document.captureEvents(Event.KEYDOWN);
	document.captureEvents(Event.KEYPRESS);
	document.captureEvents(Event.KEYUP);
}

// correspondance code/role pour les touches de fonction
var clavier_codes = new Array(256);
clavier_codes[8] = "Retour arriere";
clavier_codes[9] = "Tabulation";
clavier_codes[12] = "Milieu (pave numerique)";
clavier_codes[13] = "Entree";
clavier_codes[16] = "Shift";
clavier_codes[17] = "Ctrl";
clavier_codes[18] = "Alt";
clavier_codes[19] = "Pause";
clavier_codes[20] = "Verr Maj";
clavier_codes[27] = "Echap";
clavier_codes[33] = "Page precedente";
clavier_codes[34] = "Page suivante";
clavier_codes[35] = "Fin";
clavier_codes[36] = "Debut";
clavier_codes[37] = "Fleche gauche";
clavier_codes[38] = "Fleche haut";
clavier_codes[39] = "Fleche droite";
clavier_codes[40] = "Fleche bas";
clavier_codes[44] = "Impr ecran";
clavier_codes[45] = "Inser";
clavier_codes[46] = "Suppr";
clavier_codes[91] = "Menu Demarrer Windows";
clavier_codes[92] = "Menu Demarrer Windows";
clavier_codes[93] = "Menu contextuel Windows";
clavier_codes[112] = "F1";
clavier_codes[113] = "F2";
clavier_codes[114] = "F3";
clavier_codes[115] = "F4";
clavier_codes[116] = "F5";
clavier_codes[117] = "F6";
clavier_codes[118] = "F7";
clavier_codes[119] = "F8";
clavier_codes[120] = "F9";
clavier_codes[121] = "F10";
clavier_codes[122] = "F11";
clavier_codes[123] = "F12";
clavier_codes[144] = "Verr Num";
clavier_codes[145] = "Arret defil";

// --- Fonctions ---
	
// retourne le code clavier de la derniere touche enfoncee ou relachee
function codeTouche(e) {
	var clavier_ret;
	if (window.event) {
		if (clavier_deux > 0) clavier_ret = clavier_deux;
		else clavier_ret = window.event.keyCode;
		if (window.event.type == "keypress") clavier_deux = window.event.keyCode;
		if (window.event.type == "keydown") clavier_deux = -1;
	} else {
		if (clavier_deux > 0) clavier_ret = clavier_deux;
		else if ((clavier_un > 0) && (e.which < 1)) clavier_ret = clavier_un;
		else clavier_ret = e.which;
		if (e.type == "keydown") {
			clavier_un = e.which;
			clavier_deux = -1;
		}
		if (e.type == "keypress") clavier_deux = e.which;
	}
	return (parseInt(clavier_ret));
} // fin codeTouche(e)

// retourne le caractere ou la fonction correspondant a la derniere touche enfoncee ou relachee
function correspTouche(e) {
	var clavier_code = codeTouche(e);
	if (clavier_code == 8) return clavier_codes[clavier_code];
	if (clavier_code == 9) return clavier_codes[clavier_code];
	if (clavier_code == 13) return clavier_codes[clavier_code];
	if (clavier_code == 27) return clavier_codes[clavier_code];
	if ((clavier_codes[clavier_code]) && (clavier_deux < 1)) {
		return (clavier_codes[clavier_code]);
	} else {
		return (String.fromCharCode(clavier_code));
	}
} // fin correspTouche(e)


// retourne vrai si la touche Alt a ete enfoncee avec la derniere touche enfoncee ou relachee
function toucheAlt(e) {
	if (window.event) {
		return (window.event.altKey);
	} else {
		return (e.altKey || (e.modifiers % 2));
	}
} // fin toucheAlt(e)

// retourne vrai si la touche Ctrl a ete enfoncee avec la derniere touche enfoncee ou relachee
function toucheCtrl(e) {
	if (window.event) {
		return (window.event.ctrlKey);
	} else {
		return (e.ctrlKey || (e.modifiers == 2) || (e.modifiers == 3) || (e.modifiers > 5));
	}
} // fin toucheCtrl(e)

// retourne vrai si la touche Shift a ete enfoncee avec la derniere touche enfoncee ou relachee
function toucheShift(e) {
	if (window.event) {
		return (window.event.shiftKey);
	} else {
		return (e.shiftKey || (e.modifiers > 3));
	}
} // fin toucheShift(e)

