/* chrono.js
 * Role : simule un chronometre et affiche le temps ecoule de maniere statique ou dynamique
 * Projet: JsLib
 * Auteur : Etienne CHEVILLARD (echevillard@yahoo.fr)
 * Version  : 1.0
 * Creation : 25/04/2001
 * Mise a jour : 25/04/2001
 */

// --- Code interprete au chargement ---

// ignore les erreurs
window.onerror = function () {
	return true;
}

// variables pour la gestion du chronometre
var chrono_demarre = false;
var chrono_ecoule = 0;
var chrono_depart = 0;
var chrono_dernier = 0;

// variables pour la mise a jour dynamique
var chrono_champ;
var chrono_timeout;

// --- Fonctions ---

// Indique si le chronometre est demarre ou non
function actifChrono() {
	return (chrono_demarre);
} // fin actifChrono()

// Demarre le chronometre
function demarrerChrono() {
	// demarre si le chronometre est arrete
	if (!chrono_demarre) {
		chrono_depart = (new Date()).getTime();
		chrono_demarre = true;
	}
} // fin demarrerChrono()

// Retourne le temps mesure par le chronometre au format HH:MM:SS:CC 
function tempsChrono() {
	var chrono_now;
	// calcule le temps ecoule jusqu'a maintenant si le chronometre est demarre
	if (chrono_demarre) {
		chrono_dernier = (new Date()).getTime();
		chrono_now = new Date(chrono_ecoule + (chrono_dernier - chrono_depart));
	} else {
		chrono_now = new Date(chrono_ecoule);
	}		
	// obtient les heures, les minutes, les secondes, les centiemes de secondes 
	var chrono_h = parseInt(chrono_now.getHours()) - 1;
	var chrono_m = chrono_now.getMinutes();
	var chrono_s = chrono_now.getSeconds();
	var chrono_c = parseInt(chrono_now.getMilliseconds() / 10);
	// insere les 0 necessaires
	if (chrono_c < 10) chrono_c = "0" + chrono_c;
	if (chrono_s < 10) chrono_s = "0" + chrono_s;
	if (chrono_m < 10) chrono_m = "0" + chrono_m;
	// retourne le temps correctement formate
	return (chrono_h + ":" + chrono_m + ":" + chrono_s + ":" + chrono_c);
} // fin tempsChrono()

// Arrete le chronometre
function arreterChrono() {
	// arrete si le chronometre est demarre
	if (chrono_demarre) {
		chrono_dernier = (new Date()).getTime();
		chrono_ecoule += (chrono_dernier - chrono_depart); 
		chrono_demarre = false;
	}	
} // fin arreterChrono()

// Remet a zero le chronometre si celui-ci est arrete
function RAZChrono() {
	// met a zero si le chronometre est arrete
	if (!chrono_demarre) {
		chrono_ecoule = 0;
		chrono_depart = 0;
		chrono_dernier = 0;
	}
} // fin RAZChrono()

// Active la mise a jour dynamique du temps mesure pour le champ specifie
function chargerChronoDyna(champ) {
	if (champ) chrono_champ = eval(champ);
	chrono_champ.value = tempsChrono();
	chrono_timeout = window.setTimeout("chargerChronoDyna()", 10);
} // fin chargerChronoDyna(champ)

// Desactive la mise a jour dynamique du temps mesure precedemment activee
function dechargerChronoDyna() {
	window.clearTimeout(chrono_timeout);
} // fin dechargerChronoDyna()
