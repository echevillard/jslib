/* monnaie.js
 * Role : calcule la TVA et les montants HT et TTC, et convertit une devise en Euro
 * Projet: JsLib
 * Auteur : Etienne CHEVILLARD (echevillard@yahoo.fr)
 * Version  : 1.0
 * Creation : 30/04/2001
 * Mise a jour : 30/04/2001
 */

// --- Code interprete au chargement ---

// ignore les erreurs
window.onerror = function () {
	return true;
}

// taux par defaut
var monnaie_taux_TVA = 0.196;
var monnaie_taux_Euro = 6.55957;

// --- Fonctions ---

// Retourne le taux de TVA (en %)
function obtenirTauxTVA() {
	return (parseFloat(monnaie_taux_TVA * 100));
} // fin obtenirTauxTVA()

// Modifie le taux de TVA avec la valeur specifiee (en %)
function modifierTauxTVA(taux) {
	var monnaie_nouv = parseFloat(taux);
	if (monnaie_nouv) { 
		monnaie_taux_TVA = (monnaie_nouv / 100);
		return (true);
	} else {
		return (false);
	}
} // fin modifierTauxTVA(taux)

// Retourne un arrondi a deux decimales du montant specifie
function calculerArrondi(montant) {
	var monnaie_arr = parseFloat(montant) * 100
	monnaie_arr = Math.round(monnaie_arr) / 100;
	return (parseFloat(monnaie_arr));
} // fin calculerArrondi(montant)

// Calcule le montant TTC a partir du montant HT specifie
function calculerMontantTTC(montant) {
	var monnaie_res;
	var monnaie_ht = parseFloat(montant);
	if (monnaie_ht) {
		monnaie_res = monnaie_ht * (1 + monnaie_taux_TVA);
		monnaie_res = calculerArrondi(monnaie_res);
		return (parseFloat(monnaie_res));
	} else {
		return (0.0);
	}
} // fin calculerMontantTTC(montant)

// Calcule le montant HT a partir du montant TTC specifie
function calculerMontantHT(montant) {
	var monnaie_res;
	var monnaie_ttc = parseFloat(montant);
	if (monnaie_ttc) { 
		monnaie_res = monnaie_ttc * (1 / (1 + monnaie_taux_TVA));
		monnaie_res = calculerArrondi(monnaie_res);
		return (parseFloat(monnaie_res));
	} else {
		return (0.0);
	}
} // fin calculerMontantHT(montant)

// Calcule la TVA a appliquer sur le montant HT specifie
function calculerTVASurHT(montant) {
	var monnaie_res;
	var monnaie_ht = parseFloat(montant);
	if (monnaie_ht) { 
		monnaie_res = monnaie_ht *  monnaie_taux_TVA;
		monnaie_res = calculerArrondi(monnaie_res);
		return (parseFloat(monnaie_res));
	} else {
		return (0.0);
	}
} // fin calculerTVASurHT(montant)

// Calcule la TVA appliquee sur le montant TTC specifie
function calculerTVASurTTC(montant) {
	var monnaie_res;
	var monnaie_ttc = parseFloat(montant);
	if (monnaie_ttc) { 
		monnaie_res = monnaie_ttc * (monnaie_taux_TVA / (1 + monnaie_taux_TVA));
		monnaie_res = calculerArrondi(monnaie_res);
		return (parseFloat(monnaie_res));
	} else {
		return (0.0);
	}
} // fin calculerTVASurTTC(montant)

// Retourne le taux de conversion Euro/devise
function obtenirTauxEuro() {
	return (parseFloat(monnaie_taux_Euro));
} // fin obtenirTauxEuro()

// Modifie le taux de conversion Euro/devise avec la valeur specifiee
function modifierTauxEuro(taux) {
	var monnaie_nouv = parseFloat(taux);
	if (monnaie_nouv) { 
		monnaie_taux_Euro = monnaie_nouv;
		return (true);
	} else {
		return (false);
	}
} // fin modifierTauxEuro(taux)

// Convertit en Euro le montant specifie (en devise locale)
function convertirDeviseEnEuro(montant) {
	var monnaie_res;
	var monnaie_dev = parseFloat(montant);
	if (monnaie_dev) { 
		monnaie_res = monnaie_dev * (1 / monnaie_taux_Euro);
		monnaie_res = calculerArrondi(monnaie_res);
		return (parseFloat(monnaie_res));
	} else {
		return (0.0);
	}
} // fin convertirDeviseEnEuro(montant)

// Convertit en devise le montant specifie (en Euro)
function convertirEuroEnDevise(montant) {
	var monnaie_res;
	var monnaie_eur = parseFloat(montant);
	if (monnaie_eur) { 
		monnaie_res = monnaie_eur * monnaie_taux_Euro;
		monnaie_res = calculerArrondi(monnaie_res);
		return (parseFloat(monnaie_res));
	} else {
		return (0.0);
	}
} // fin convertirEuroEnDevise(montant)
