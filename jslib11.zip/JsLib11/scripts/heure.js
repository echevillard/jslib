/* heure.js
 * Role : formate l'heure courante et l'affiche de maniere statique ou dynamique
 * Projet: JsLib
 * Auteur : Etienne CHEVILLARD (echevillard@yahoo.fr)
 * Version  : 1.0
 * Creation : 24/04/2001
 * Mise a jour : 25/04/2001
 */

// --- Code interprete au chargement ---

// ignore les erreurs
window.onerror = function () {
	return true;
}

// variables pour la mise a jour dynamique
var heure_champ;
var heure_timeout;

// --- Fonctions ---

// Retourne l'heure courante en abrege, au format HH:MM
function heureCourAbr() {
	// obtient les heures et les minutes
	var heure_date = new Date();
	var heure_h = heure_date.getHours();
	var heure_m = heure_date.getMinutes();
	// insere les 0 necessaires
	if (heure_m < 10) heure_m = "0" + heure_m;
	// retourne l'heure correctement formatee
	return (heure_h + ":" + heure_m);	 
} // fin heureCourAbr()

// Retourne l'heure courante au format HH:MM:SS
function heureCour() {
	// obtient les heures, les minutes et les secondes
	var heure_date = new Date();
	var heure_h = heure_date.getHours();
	var heure_m = heure_date.getMinutes();
	var heure_s = heure_date.getSeconds();
	// insere les 0 necessaires
	if (heure_s < 10) heure_s = "0" + heure_s;
	if (heure_m < 10) heure_m = "0" + heure_m;	
	// retourne l'heure correctement formatee
	return (heure_h + ":" + heure_m + ":" + heure_s);	 
} // fin heureCour()

// Retourne l'heure courante au format HH heure(s) MM
function heureCourLng() {
	// obtient les heures et les minutes
	var heure_date = new Date();
	var heure_h = heure_date.getHours();
	var heure_m = heure_date.getMinutes();
	// insere les 0 necessaires
	if (heure_m < 10) heure_m = "0" + heure_m;
	if (heure_m < 1) heure_m = "";
	else heure_m = " " + heure_m;
	// retourne l'heure correctement formatee
	if (heure_h > 1) return (heure_h + " heures" + heure_m);
	else return (heure_h + " heure" + heure_m);	 
} // fin heureCourLng()

// Active la mise a jour dynamique de l'heure pour le champ specifie
function chargerHeureDyna(champ) {
	if (champ) heure_champ = eval(champ);
	heure_champ.value = heureCour();
	heure_timeout = window.setTimeout("chargerHeureDyna()", 1000);
} // fin chargerHeureDyna(champ)

// Desactive la mise a jour dynamique de l'heure precedemment activee
function dechargerHeureDyna() {
	window.clearTimeout(heure_timeout);
} // fin dechargerHeureDyna()
