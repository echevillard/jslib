/* dyna.js
 * Role : controle les divisions (ou couches) des pages Web dynamiques 
 * Projet: JsLib
 * Auteur : Etienne CHEVILLARD (echevillard@yahoo.fr)
 * Version  : 1.0
 * Creation : 7/07/2001
 * Mise a jour : 27/08/2001
 * Bogues connues :	- la modification des dimensions d'une division avant une premiere modification 
 *				  du contenu pose des problemes sous Netscape 4			
 *					- Opera 5 ne gere pas la couleur de fond "transparent" des divisions
 *					 - Opera 5 ne gere pas la modification du contenu des divisions
 */

// --- Code interprete au chargement ---

// ignore les erreurs
window.onerror = function () {
	return true;
}

// definit des variables pour le choix du DOM (Document Object Model)
var dyna_w3 = 0;	// DOM-1 du W3C, Netscape 6, Internet Explorer 5 et 6
var dyna_ie = 0;	// Internet Explorer 4
var dyna_nn = 0;	// Netscape Navigator 4
var dyna_op = 0;	// Opera 4 et 5

// determine le DOM utilise par le navigateur
if (navigator.userAgent.toLowerCase().indexOf('opera') != -1) { dyna_op = 1; }
else if (document.getElementById && document.getElementsByTagName) { dyna_w3 = 1; }
else if (document.all) { dyna_ie = 1; }
else if (document.layers) {	dyna_nn = 1; }

// annule la reconnaissance du DOM par Sun HotJava 3 (bug)
if (navigator.userAgent.toLowerCase().indexOf("hotjava") != -1) { dyna_nn = 0; }

// recharge la page en cas de redimensionnement de la fenetre de Netscape 4 (bug)
window.onresize = function () {
	if (dyna_nn) { history.go(0); }
}

// --- Fonctions ---

// Indique si le navigateur accepte le DHTML
function accepteDHTML() {
	return (dyna_w3 || dyna_ie || dyna_nn || dyna_op);
} // fin accepteDHTML()

// Rend visible la division specifiee
function montrerDivision(id) {
	if (dyna_w3) {
		document.getElementById(id).style.visibility = "visible";
	} else if (dyna_ie || dyna_op) {
		document.all[id].style.visibility = "visible";
	} else if (dyna_nn) {
		document.layers[id].visibility = "show";
	}
} // fin montrerDivision(id)

// Rend invisible la division specifiee
function cacherDivision(id) {
	if (dyna_w3) {
		document.getElementById(id).style.visibility = "hidden";
	} else if (dyna_ie || dyna_op) {
		document.all[id].style.visibility = "hidden";
	} else if (dyna_nn) {
		document.layers[id].visibility = "hide";
	}
} // fin cacherDivision(id)

// Modifie l'index de superposition de la division specifiee
function zIndexDivision(id, z) {
	if ((isNaN(parseInt(z))) || (parseInt(z) < 0)) { z = 0;	}
	if (dyna_w3) {
		document.getElementById(id).style.zIndex = z;
	} else if (dyna_ie || dyna_op) {
		document.all[id].style.zIndex = z;
	} else if (dyna_nn) {
		document.layers[id].zIndex = z;
	}
} // fin zIndexDivision(id, z)

// Deplace la division specifiee vers les coordonnees specifiees
function deplacerDivisionVers(id, x, y) {
	if (isNaN(parseInt(x))) { x = 0; }
	if (isNaN(parseInt(y))) { y = 0; }
	if (dyna_w3) {
		document.getElementById(id).style.left = x;
		document.getElementById(id).style.top = y;
	} else if (dyna_ie || dyna_op) {
		document.all[id].style.pixelLeft = x;
		document.all[id].style.pixelTop = y;
	} else if (dyna_nn) {
		document.layers[id].left = x;
		document.layers[id].top = y;
	}
} // fin deplacerDivisionVers(id, x, y)

// Deplace la division specifiee du nombre de pixels specifie
function deplacerDivisionDe(id, px, py) {
	if (isNaN(parseInt(px))) { px = 0; }
	if (isNaN(parseInt(py))) { py = 0; }
	if (dyna_w3) {
		document.getElementById(id).style.left = parseInt(document.getElementById(id).style.left) + px;
		document.getElementById(id).style.top = parseInt(document.getElementById(id).style.top) + py;
	} else if (dyna_ie || dyna_op) {
		document.all[id].style.pixelLeft = parseInt(document.all[id].style.pixelLeft) + px;
		document.all[id].style.pixelTop = parseInt(document.all[id].style.pixelTop) + py;
	} else if (dyna_nn) {
		document.layers[id].left = parseInt(document.layers[id].left) + px;
		document.layers[id].top = parseInt(document.layers[id].top) + py;
	}
} // fin deplacerDivisionDe(id, px, py)

// Modifie les dimensions de la division specifiee
function dimensionsDivision(id, largeur, hauteur) {
	if ((isNaN(parseInt(largeur))) || (parseInt(largeur) < 0)) { largeur = 0; }
	if ((isNaN(parseInt(hauteur))) || (parseInt(hauteur) < 0)) { hauteur = 0; }
	if (dyna_w3) {
		document.getElementById(id).style.width = largeur;
		document.getElementById(id).style.height = hauteur;
	} else if (dyna_ie || dyna_op) {
		document.all[id].style.pixelWidth = largeur;
		document.all[id].style.pixelHeight = hauteur;
	} else if (dyna_nn) {
		document.layers[id].document.width = largeur;
		document.layers[id].document.height = hauteur;
		document.layers[id].clip.top = 0;
		document.layers[id].clip.left = 0;
		document.layers[id].clip.right = largeur;
		document.layers[id].clip.bottom = hauteur;
	}
} // fin dimensionsDivision(id, largeur, hauteur)

// Modifie la couleur de fond de la division specifiee
function couleurFondDivision(id, couleur) {
	if ((!couleur) || (couleur == "")) { couleur = "transparent"; }
	if (dyna_op) {
		document.all[id].style.background = couleur;
	} else if (dyna_w3) {
		document.getElementById(id).style.backgroundColor = couleur;
	} else if (dyna_ie) {
		document.all[id].style.backgroundColor = couleur;		
	} else if (dyna_nn) {
		if (couleur.toLowerCase() == "transparent") { document.layers[id].bgColor = null; }
		else document.layers[id].bgColor = couleur;
	}
} // fin couleurFondDivision(id, couleur)

// Modifie l'image de fond de la division specifiee
function imageFondDivision(id, image) {
	if (dyna_w3) {
		if ((!image) || (image == "")) { document.getElementById(id).style.backgroundImage = ""; }
		else document.getElementById(id).style.backgroundImage = "url(" + image + ")";
	} else if (dyna_ie|| dyna_op) {
		if ((!image) || (image == "")) { document.getElementById(id).style.backgroundImage = "url(null)"; }
		else document.all[id].style.backgroundImage = "url(" + image + ")";
	} else if (dyna_nn) {
		if ((!image) || (image == "")) { couleurFondDivision(id, document.layers[id].bgColor); }
		document.layers[id].background.src = image;
	}
} // fin imageFondDivision(id, image)

// Modifie le code HTML contenu dans la division specifiee
function ecrireDivision(id, texte) {
	if (!texte) { texte = ""; }
	if (navigator.userAgent.toLowerCase().indexOf("mac") != -1) { texte += "\n"; }	
	if (dyna_w3) {
		document.getElementById(id).innerHTML = texte;		
	} else if (dyna_ie || dyna_op) {
		document.all[id].innerHTML = texte;
	} else if (dyna_nn) {
		document.eval("layers[id]").document.open();
		document.eval("layers[id]").document.write(texte);
		document.eval("layers[id]").document.close();
	}
} // fin ecrireDivision(id, texte)
