/* forms.js
 * Role : formate, controle et recupere le contenu des formulaires
 * Projet : JsLib
 * Auteur : Etienne CHEVILLARD (etienne@chevillard.org)
 * Version : 1.2
 * Creation : 2/05/2001
 * Mise a jour : 29/01/2003
 */

// ignore les erreurs
window.onerror=function () {
  return true;
}

// variables pour les parametres de l'URL
var forms_cle;
var forms_val;

// recupere les parametres de l'URL
if (window.location.search && (window.location.search.indexOf("=")>1)) {
  var fpar=(window.location.search.substring(1, window.location.search.length)).split("&");
  forms_cle=new Array(fpar.length);
  forms_val=new Array(fpar.length);
  for (var i=0; i<fpar.length; i++) {
    forms_cle[i]=fpar[i].substring(0, fpar[i].indexOf("="));
    forms_val[i]=fpar[i].substring(fpar[i].indexOf("=")+1, fpar[i].length);
    forms_val[i]=unescape((forms_val[i].split("+")).join(" "));
  }
}

// --- Fonctions ---

// supprime les espaces qui commencent ou qui terminent la chaine specifiee
function forms_suppEsp(chaine) {
  var fdeb;
  var ffin;
  // enleve les espaces a gauche
  fdeb=chaine;
  ffin=chaine;
  for(var i=0; ((i<fdeb.length) && (fdeb.charAt(i)==' ')); i++) {
    ffin=ffin.substring(1, ffin.length);
  }
  // enleve les espaces a droite
  fdeb=ffin;
  for(var i=fdeb.length-1; ((i>=0) && (fdeb.charAt(i)==' ')); i--)
    ffin=ffin.substring(0, ffin.length-1);
  // retourne la chaine obtenue
  return (ffin);
} // fin forms_suppEsp(chaine)

// verifie que le formulaire specifie est rempli puis l'expedie
function envoyerFormulaire(formulaire) {
  // verifie que tous les champs du formulaire sont remplis
  for (var i=0; i<formulaire.elements.length; i++) {
    if (! verifierPresence(formulaire.elements[i].value)) {
      alert("Erreur : le champ \""+formulaire.elements[i].name+"\" est vide.");
      formulaire.elements[i].focus();
      return false;
    }
  }
  // expedie le formulaire
  formulaire.submit();
  return true;
} // fin envoyerFormulaire(formulaire)

// formate le contenu d'un champ de formulaire de type "Email"
function formaterChampEmail(champ) {
  var femail;
  femail=champ.value;
  // supprime les eventuels<> "
  femail=femail.split('<').join('');
  femail=femail.split('>').join('');
  femail=femail.split('"').join('');
  // enleve les espaces superflus
  femail=femail.split(' ').join('');
  // met a jour le champ
  champ.value=femail;
  return true;
} // fin formaterChampEmail(champ)

// formate le contenu d'un champ de formulaire de type "Nom"
function formaterChampNom(champ) {
  var fnom;
  var fpos;
  // enleve les espaces superflus a gauche et a droite
  fnom=forms_suppEsp(champ.value);
  // enleve les espaces superflus au milieu
  for(var i=0; i<fnom.length-1; i++) {
    while ((fnom.charAt(i)==' ') && (fnom.charAt(i+1)==' ')) {
      fnom=fnom.substring(0, i)
       +fnom.substring(i+1, fnom.length);
    }
  }
  // met la premiere lettre du nom en majuscule
  fnom=fnom.substring(0, 1).toUpperCase()
   +fnom.substring(1, fnom.length).toLowerCase();
  // met la premiere lettre de chaque mot en majuscule
  for(var i=0; i<fnom.length-1; i++) {
    if ((fnom.charAt(i)=='-') || (fnom.charAt(i)==' ')) {
      fnom=fnom.substring(0, i)+fnom.charAt(i)
       +fnom.substring(i+1, i+2).toUpperCase()
       +fnom.substring(i+2, fnom.length);
    }
  }
  // met a jour le champ
  champ.value=fnom;
  return true;
} // fin formaterChampNom(champ)

// formate et retourne les parametres contenus dans l'URL de la page
function formaterParametres() {
  if (!window.location.search) { return ""; }
  // formate chaque couple cle/valeur
  var ftxt;
  ftxt="<TABLE BORDER=0 CELLSPACING=2 CELLPADDING=2>";
  for (var i=0; i<forms_cle.length; i++) {
    ftxt+="<TR><TD VALIGN=\"TOP\"><B>" + forms_cle[i] + " :</B></TD>";
    ftxt+="<TD VALIGN=\"TOP\"><PRE>" + forms_val[i] + "</TD></TR>";
  }
  ftxt+="</TABLE>";
  // retourne le resultat
  return (ftxt);
} // fin formaterParametres()

// retourne le nombre de parametres contenus dans l'URL de la page
function nombreParametres() {
  if (window.location.search && (window.location.search.indexOf("=")>1)) {
    return (forms_cle.length);
  } else {
    return (0);
  }
} // fin nombreParametres()

// retourne la valeur du parametre correspondant a la cle indiquee
function valeurParametre(cle) {
  if (window.location.search) {
    for (var i=0; i<forms_cle.length; i++) {
      if (forms_cle[i]==forms_suppEsp(cle)) return (forms_val[i]);
    }
  }
  // si cle incorrecte
  return ("");
} // fin valeurParametre(cle)

// verifie que l'adresse e-mail specifiee est valide
function verifierEmail(email) {
  var fadr;
  var fnom;
  var farob;
  var fdom;
  var fpoint;
  var fext;
  // verifie la presence d'une chaine
  if (! verifierPresence(email)) { return false; }
  // enleve les espaces superflus a gauche et a droite
  fadr=forms_suppEsp(email);
  // obtient et verifie la position de l'arobase
  farob=fadr.lastIndexOf("@");
  if (farob!=fadr.indexOf("@")) { return false; }
  // extrait et verifie le nom
  fnom=fadr.substring(0, farob);
  if (fnom.length<1) { return false; }
  // verifie le point entre le domaine et l'extension
  fpoint=fadr.lastIndexOf(".");
  if (fpoint<farob) { return false; }
  // extrait et verifie l'extension
  fext=fadr.substring(fpoint+1, fadr.length);
  if (fext.length<2) { return false; }
  // extrait et verifie le domaine
  fdom=fadr.substring(farob+1, fpoint);
  if (fdom.length<2) { return false; }
  return true;
} // fin verifierEmail(email)

// verifie que la chaine specifiee n'est pas vide
function verifierPresence(chaine) {
  if (forms_suppEsp(chaine).length>0) { return true; }
  else { return false; }
} // fin verifierPresence(chaine)
