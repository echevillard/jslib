/* heure.js
 * Role : formate l'heure courante et l'affiche de maniere statique ou dynamique
 * Projet : JsLib
 * Auteur : Etienne CHEVILLARD (etienne@chevillard.org)
 * Version : 1.2
 * Creation : 24/04/2001
 * Mise a jour : 29/01/2003
 */

// ignore les erreurs
window.onerror=function () {
  return true;
}

// variables pour la mise a jour dynamique
var heure_champ;
var heure_timeout;

// --- Fonctions ---

// active la mise a jour dynamique de l'heure pour le champ specifie
function chargerHeureDyna(champ) {
  if (champ) heure_champ=eval(champ);
  heure_champ.value=heureCour();
  heure_timeout=window.setTimeout("chargerHeureDyna()", 1000);
  return true;
} // fin chargerHeureDyna(champ)

// desactive la mise a jour dynamique de l'heure precedemment activee
function dechargerHeureDyna() {
  window.clearTimeout(heure_timeout);
  return true;
} // fin dechargerHeureDyna()

// retourne l'heure courante au format HH:MM:SS
function heureCour() {
  // obtient les heures, les minutes et les secondes
  var h_date=new Date();
  var h_h=h_date.getHours();
  var h_m=h_date.getMinutes();
  var h_s=h_date.getSeconds();
  // insere les 0 necessaires
  if (h_s<10) h_s="0"+h_s;
  if (h_m<10) h_m="0"+h_m;
  // retourne l'heure correctement formatee
  return (h_h+":"+h_m+":"+h_s);
} // fin heureCour()

// retourne l'heure courante en abrege, au format HH:MM
function heureCourAbr() {
  // obtient les heures et les minutes
  var h_date=new Date();
  var h_h=h_date.getHours();
  var h_m=h_date.getMinutes();
  // insere les 0 necessaires
  if (h_m<10) h_m="0"+h_m;
  // retourne l'heure correctement formatee
  return (h_h+":"+h_m);
} // fin heureCourAbr()

// retourne l'heure courante au format HH heure(s) MM
function heureCourLng() {
  // obtient les heures et les minutes
  var h_date=new Date();
  var h_h=h_date.getHours();
  var h_m=h_date.getMinutes();
  // insere les 0 necessaires
  if (h_m<10) h_m="0"+h_m;
  if (h_m<1) h_m="";
  else h_m=" "+h_m;
  // retourne l'heure correctement formatee
  if (h_h>1) return (h_h+" heures"+h_m);
  else return (h_h+" heure"+h_m);
} // fin heureCourLng()
