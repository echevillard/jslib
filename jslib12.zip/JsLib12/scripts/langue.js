/* langue.js
 * Role : detecte la langue du navigateur du client
 * Projet : JsLib
 * Auteur : Etienne CHEVILLARD (etienne@chevillard.org)
 * Version : 1.2
 * Creation : 10/04/2001
 * Mise a jour : 29/01/2003
 */

// ignore les erreurs
window.onerror=function () {
  return true;
}

// tableau des langues abregees
var langue_tabct=new Array(76);
langue_tabct[0]="af";
langue_tabct[1]="sq";
langue_tabct[2]="de";
langue_tabct[3]="en";
langue_tabct[4]="ar";
langue_tabct[5]="hy";
langue_tabct[6]="as";
langue_tabct[7]="az";
langue_tabct[8]="eu";
langue_tabct[9]="bn";
langue_tabct[10]="be";
langue_tabct[11]="bg";
langue_tabct[12]="ca";
langue_tabct[13]="zh";
langue_tabct[14]="ko";
langue_tabct[15]="hr";
langue_tabct[16]="da";
langue_tabct[17]="es";
langue_tabct[18]="et";
langue_tabct[19]="fa";
langue_tabct[20]="fo";
langue_tabct[21]="fi";
langue_tabct[22]="fr";
langue_tabct[23]="gd";
langue_tabct[24]="ka";
langue_tabct[25]="el";
langue_tabct[26]="gu";
langue_tabct[27]="he";
langue_tabct[28]="hi";
langue_tabct[29]="hu";
langue_tabct[30]="id";
langue_tabct[31]="is";
langue_tabct[32]="it";
langue_tabct[33]="ja";
langue_tabct[34]="kn";
langue_tabct[35]="kk";
langue_tabct[36]="lv";
langue_tabct[37]="lt";
langue_tabct[38]="lk";
langue_tabct[39]="ms";
langue_tabct[40]="ml";
langue_tabct[41]="mt";
langue_tabct[42]="mr";
langue_tabct[43]="nl";
langue_tabct[44]="ne";
langue_tabct[45]="no";
langue_tabct[46]="or";
langue_tabct[47]="ur";
langue_tabct[48]="uz";
langue_tabct[49]="pa";
langue_tabct[50]="pl";
langue_tabct[51]="pt";
langue_tabct[52]="rm";
langue_tabct[53]="ro";
langue_tabct[54]="ru";
langue_tabct[55]="sa";
langue_tabct[56]="sr";
langue_tabct[57]="sk";
langue_tabct[58]="sl";
langue_tabct[59]="sb";
langue_tabct[60]="sv";
langue_tabct[61]="sx";
langue_tabct[62]="sw";
langue_tabct[63]="ta";
langue_tabct[64]="tt";
langue_tabct[65]="cs";
langue_tabct[66]="te";
langue_tabct[67]="th";
langue_tabct[68]="ts";
langue_tabct[69]="tn";
langue_tabct[70]="tr";
langue_tabct[71]="uk";
langue_tabct[72]="vi";
langue_tabct[73]="xh";
langue_tabct[74]="yi";
langue_tabct[75]="zu";

// tableau des langues
var langue_tablg=new Array(76);
langue_tablg[0]="Afrikaans";
langue_tablg[1]="Albanais";
langue_tablg[2]="Allemand";
langue_tablg[3]="Anglais";
langue_tablg[4]="Arabe";
langue_tablg[5]="Arm&eacute;nien";
langue_tablg[6]="Assamais";
langue_tablg[7]="Az&eacute;ri";
langue_tablg[8]="Basque";
langue_tablg[9]="Bengali";
langue_tablg[10]="Bi&eacute;lorusse";
langue_tablg[11]="Bulgare";
langue_tablg[12]="Catalan";
langue_tablg[13]="Chinois";
langue_tablg[14]="Cor&eacute;en";
langue_tablg[15]="Croate";
langue_tablg[16]="Danois";
langue_tablg[17]="Espagnol";
langue_tablg[18]="Estonien";
langue_tablg[19]="Farsi";
langue_tablg[20]="F&eacute;ro&icirc;en";
langue_tablg[21]="Finnois";
langue_tablg[22]="Fran&ccedil;ais";
langue_tablg[23]="Ga&eacute;lique";
langue_tablg[24]="G&eacute;orgien";
langue_tablg[25]="Grec";
langue_tablg[26]="Gujarati";
langue_tablg[27]="H&eacute;breu";
langue_tablg[28]="Hindi";
langue_tablg[29]="Hongrois";
langue_tablg[30]="Indon&eacute;sien";
langue_tablg[31]="Islandais";
langue_tablg[32]="Italien";
langue_tablg[33]="Japonais";
langue_tablg[34]="Kannada";
langue_tablg[35]="Kazakh";
langue_tablg[36]="Letton";
langue_tablg[37]="Lituanien";
langue_tablg[38]="Mac&eacute;donien";
langue_tablg[39]="Malais";
langue_tablg[40]="Malayalam";
langue_tablg[41]="Maltais";
langue_tablg[42]="Marathi";
langue_tablg[43]="N&eacute;erlandais";
langue_tablg[44]="N&eacute;palais";
langue_tablg[45]="Norv&eacute;gien";
langue_tablg[46]="Oriya";
langue_tablg[47]="Ourdou";
langue_tablg[48]="Ouzbek";
langue_tablg[49]="Pendjabi";
langue_tablg[50]="Polonais";
langue_tablg[51]="Portugaus";
langue_tablg[52]="Rh&eacute;to-roman";
langue_tablg[53]="Roumain";
langue_tablg[54]="Russe";
langue_tablg[55]="Sanskrit";
langue_tablg[56]="Serbe";
langue_tablg[57]="Slovaque";
langue_tablg[58]="Slov&egrave;ne";
langue_tablg[59]="Slorabe";
langue_tablg[60]="Su&eacute;dois";
langue_tablg[61]="Sutu";
langue_tablg[62]="Swahili";
langue_tablg[63]="Tamoul";
langue_tablg[64]="Tatar";
langue_tablg[65]="Tch&egrave;que";
langue_tablg[66]="Telugou";
langue_tablg[67]="Tha&iuml;";
langue_tablg[68]="Tsonga";
langue_tablg[69]="Tswana";
langue_tablg[70]="Turc";
langue_tablg[71]="Ukrainien";
langue_tablg[72]="Vietnamien";
langue_tablg[73]="Xhosa";
langue_tablg[74]="Yiddish";
langue_tablg[75]="Zoulou";

// langue par defaut : Anglais
var langue_ct="en";
var langue_lg="Anglais";

// recupere la langue utilisee
if (navigator.language) {
  langue_ct=navigator.language.toLowerCase().substring(0, 2);
} else if (navigator.userLanguage) {
  langue_ct=navigator.userLanguage.toLowerCase().substring(0, 2);
} else if (navigator.userAgent.indexOf("[")!=-1) {
  var debut=navigator.userAgent.indexOf("[");
  var fin=navigator.userAgent.indexOf("]");
  langue_ct=navigator.userAgent.substring(debut+1, fin).toLowerCase();
}

// --- Fonctions ---

// fonction depreciee - conservee pour compatibilite
function langueAbrNavig() { return (langue_ct); }

// retourne la langue du navigateur en francais
function langueNavig() {
  // effectue la correspondance
  for (var i=0; i<langue_tabct.length; i++) {
    if (langue_tabct[i]==langue_ct) {
      langue_lg=langue_tablg[i];
    }
  }
  return (langue_lg);
} // fin langueNavig()

// retourne la langue du navigateur en abrege
function langueNavigAbr() {
  return (langue_ct);
} // fin langueNavigAbr()


