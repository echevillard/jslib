/* dyna.js
 * Role : controle les divisions (ou couches) des pages Web dynamiques
 * Projet : JsLib
 * Auteur : Etienne CHEVILLARD (etienne@chevillard.org)
 * Version : 1.2
 * Creation : 7/07/2001
 * Mise a jour : 29/01/2003
 * Bogues connues : - la modification des dimensions d'une division avant une premiere
*                 modification du contenu pose des problemes sous Netscape 4
*                 - Opera 5/6 ne gere pas la couleur de fond "transparent"
*                 - Opera 5/6 ne gere pas la modification du contenu des divisions
 */

// ignore les erreurs
window.onerror=function () {
  return true;
}

// definit des variables pour le choix du DOM (Document Object Model)
var dyna_w3=0;  // DOM-1 du W3C : Mozilla 1, Netscape 6/7, IE 5/6, Opera 7
var dyna_ie=0;  // IE 4
var dyna_nn=0;  // Netscape Navigator 4
var dyna_op=0;  // Opera 4/5/6

// determine le DOM utilise par le navigateur
if (document.getElementById && document.getElementsByTagName) { dyna_w3=1; }
else if (navigator.userAgent.toLowerCase().indexOf('opera')!=-1) { dyna_op=1; }
else if (document.all) { dyna_ie=1; }
else if (document.layers) { dyna_nn=1; }

// recharge la page si redimensionnement de la fenetre sous Netscape 4 (boque)
window.onresize=function () {
  if (dyna_nn) { history.go(0); }
}

// --- Fonctions ---

// indique si le navigateur accepte le DHTML
function accepteDHTML() {
  return (dyna_w3 || dyna_ie || dyna_nn || dyna_op);
} // fin accepteDHTML()

// rend invisible la division specifiee
function cacherDivision(id) {
  if (dyna_w3) {
    document.getElementById(id).style.visibility="hidden";
  } else if (dyna_ie || dyna_op) {
    document.all[id].style.visibility="hidden";
  } else if (dyna_nn) {
    document.layers[id].visibility="hide";
  }
  return true;
} // fin cacherDivision(id)

// modifie la couleur de fond de la division specifiee
function couleurFondDivision(id, couleur) {
  if ((!couleur) || (couleur=="")) { couleur="transparent"; }
  if (dyna_op) {
    document.all[id].style.background=couleur;
  } else if (dyna_w3) {
    document.getElementById(id).style.backgroundColor=couleur;
  } else if (dyna_ie || dyna_op) {
    document.all[id].style.backgroundColor=couleur;
  } else if (dyna_nn) {
    if (couleur.toLowerCase()=="transparent") { document.layers[id].bgColor=null; }
    else document.layers[id].bgColor=couleur;
  }
  return true;
} // fin couleurFondDivision(id, couleur)

// deplace la division specifiee du nombre de pixels specifie
function deplacerDivisionDe(id, px, py) {
  if (isNaN(px)) { px=0; }
  if (isNaN(py)) { py=0; }
  if (dyna_w3) {
    document.getElementById(id).style.left=parseInt(document.getElementById(id).style.left)+px;
    document.getElementById(id).style.top=parseInt(document.getElementById(id).style.top)+py;
  } else if (dyna_ie || dyna_op) {
    document.all[id].style.pixelLeft=parseInt(document.all[id].style.pixelLeft)+px;
    document.all[id].style.pixelTop=parseInt(document.all[id].style.pixelTop)+py;
  } else if (dyna_nn) {
    document.layers[id].left=parseInt(document.layers[id].left)+px;
    document.layers[id].top=parseInt(document.layers[id].top)+py;
  }
  return true;
} // fin deplacerDivisionDe(id, px, py)

// deplace la division specifiee vers les coordonnees specifiees
function deplacerDivisionVers(id, x, y) {
  if (isNaN(x)) { x=0; }
  if (isNaN(y)) { y=0; }
  if (dyna_w3) {
    document.getElementById(id).style.left=x;
    document.getElementById(id).style.top=y;
  } else if (dyna_ie || dyna_op) {
    document.all[id].style.pixelLeft=x;
    document.all[id].style.pixelTop=y;
  } else if (dyna_nn) {
    document.layers[id].left=x;
    document.layers[id].top=y;
  }
  return true;
} // fin deplacerDivisionVers(id, x, y)

// modifie les dimensions de la division specifiee
function dimensionsDivision(id, largeur, hauteur) {
  if ((isNaN(largeur)) || (parseInt(largeur)<0)) { largeur=0; }
  if ((isNaN(hauteur)) || (parseInt(hauteur)<0)) { hauteur=0; }
  if (dyna_w3) {
    document.getElementById(id).style.width=largeur;
    document.getElementById(id).style.height=hauteur;
  } else if (dyna_ie || dyna_op) {
    document.all[id].style.pixelWidth=largeur;
    document.all[id].style.pixelHeight=hauteur;
  } else if (dyna_nn) {
    document.layers[id].document.width=largeur;
    document.layers[id].document.height=hauteur;
    document.layers[id].clip.top=0;
    document.layers[id].clip.left=0;
    document.layers[id].clip.right=largeur;
    document.layers[id].clip.bottom=hauteur;
  }
  return true;
} // fin dimensionsDivision(id, largeur, hauteur)

// modifie le code HTML contenu dans la division specifiee
function ecrireDivision(id, texte) {
  if (!texte) { texte=""; }
  if (navigator.userAgent.toLowerCase().indexOf("mac")!=-1) { texte+="\n"; }
  if (dyna_w3) {
    document.getElementById(id).innerHTML="";
    document.getElementById(id).innerHTML=texte;
  } else if (dyna_ie || dyna_op) {
    document.all[id].innerHTML=texte;
  } else if (dyna_nn) {
    document.layers[id].document.open();
    document.layers[id].document.write(texte);
    document.layers[id].document.close();
  }
  return true;
} // fin ecrireDivision(id, texte)

// retourne la hauteur de la zone de navigation
function hauteurZoneNavig() {
  if (self.innerHeight)
  	return (self.innerHeight);
  else if (document.documentElement && document.documentElement.clientHeight)
    return (document.documentElement.clientHeight);
  else if (document.body)
    return (document.body.clientHeight);
  else return (0);
} // fin hauteurZoneNavig()

// modifie l'image de fond de la division specifiee
function imageFondDivision(id, image) {
  if (dyna_w3) {
    if ((!image) || (image=="")) { document.getElementById(id).style.backgroundImage="url(null)"; }
    else document.getElementById(id).style.backgroundImage="url("+image+")";
  } else if (dyna_ie || dyna_op) {
    if ((!image) || (image=="")) { document.getElementById(id).style.backgroundImage="url(null)"; }
    else document.all[id].style.backgroundImage="url("+image+")";
  } else if (dyna_nn) {
    if ((!image) || (image=="")) { couleurFondDivision(id, document.layers[id].bgColor); }
    document.layers[id].background.src=image;
  }
  return true;
} // fin imageFondDivision(id, image)

// retourne la largeur de la zone de navigation
function largeurZoneNavig() {
  if (self.innerWidth)
  	return (self.innerWidth);
  else if (document.documentElement && document.documentElement.clientWidth)
    return (document.documentElement.clientWidth);
  else if (document.body)
    return (document.body.clientWidth);
  else return (0);
} // fin largeurZoneNavig()

// rend visible la division specifiee
function montrerDivision(id) {
  if (dyna_w3) {
    document.getElementById(id).style.visibility="visible";
  } else if (dyna_ie || dyna_op) {
    document.all[id].style.visibility="visible";
  } else if (dyna_nn) {
    document.layers[id].visibility="show";
  }
  return true;
} // fin montrerDivision(id)

// modifie l'index de superposition de la division specifiee
function zIndexDivision(id, z) {
  if ((isNaN(z)) || (parseInt(z)<0)) { z=0;  }
  if (dyna_w3) {
    document.getElementById(id).style.zIndex=z;
  } else if (dyna_ie || dyna_op) {
    document.all[id].style.zIndex=z;
  } else if (dyna_nn) {
    document.layers[id].zIndex=z;
  }
  return true;
} // fin zIndexDivision(id, z)
