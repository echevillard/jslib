/* medias.js
 * Role : insere un media audio ou video dans la page Web courante
 * Projet : JsLib
 * Auteur : Etienne CHEVILLARD (etienne@chevillard.org)
 * Version : 1.2
 * Creation : 14/09/2002
 * Mise a jour : 29/01/2003
 * Bogues connues :
 */

// ignore les erreurs
window.onerror=function () {
  return true;
}

// variables communes
var medias_agt=navigator.userAgent.toLowerCase();
var medias_ie=((medias_agt.indexOf("msie")!=-1) && (medias_agt.indexOf("opera")==-1));

// tableau des extensions
var medias_ext=new Array(30);
medias_ext[0]="class";
medias_ext[1]="swf";
medias_ext[2]="au,snd";
medias_ext[3]="mp2,mp3";
medias_ext[4]="aif,aiff,aifc";
medias_ext[5]="wav";
medias_ext[6]="dus,cht";
medias_ext[7]="mid,midi";
medias_ext[8]="rm,ra,ram";
medias_ext[9]="rpm";
medias_ext[10]="cmu,ras";
medias_ext[11]="fh4,fh5,fhc";
medias_ext[12]="gif";
medias_ext[13]="ief";
medias_ext[14]="jpg,jpe,jpeg";
medias_ext[15]="tif,tiff";
medias_ext[16]="pnm";
medias_ext[17]="pbm";
medias_ext[18]="pgm";
medias_ext[19]="ppm";
medias_ext[20]="rgb";
medias_ext[21]="xbm";
medias_ext[22]="xpm";
medias_ext[23]="xwd";
medias_ext[24]="mpg,mpe,mpeg";
medias_ext[25]="qt,mov";
medias_ext[26]="wma,wmv,asf";
medias_ext[27]="avi,vfw";
medias_ext[28]="movie";
medias_ext[29]="wrl,vrml";

// tableau des types MIME
var medias_mim=new Array(30);
medias_mim[0]="application/octet-stream";
medias_mim[1]="application/x-shockwave-flash";
medias_mim[2]="audio/basic";
medias_mim[3]="audio/mpeg";
medias_mim[4]="audio/x-aiff";
medias_mim[5]="audio/x-wav";
medias_mim[6]="audio/x-dspeeh";
medias_mim[7]="audio/x-midi";
medias_mim[8]="audio/x-pn-realaudio";
medias_mim[9]="audio/x-pn-realaudio-plugin";
medias_mim[10]="image/x-cmu-raster";
medias_mim[11]="image/x-freehand";
medias_mim[12]="image/gif";
medias_mim[13]="image/ief";
medias_mim[14]="image/jpeg";
medias_mim[15]="image/tiff";
medias_mim[16]="image/x-portable-anymap";
medias_mim[17]="image/x-portable-bitmap";
medias_mim[18]="image/x-portable-graymap";
medias_mim[19]="image/x-portable-pixmap";
medias_mim[20]="image/x-rgb";
medias_mim[21]="image/x-xbitmap";
medias_mim[22]="image/x-xpixmap";
medias_mim[23]="image/x-xwindowdump";
medias_mim[24]="video/mpeg";
medias_mim[25]="video/quicktime";
medias_mim[26]="video/x-ms-asf";
medias_mim[27]="video/x-msvideo";
medias_mim[28]="video/x-sgi-movie";
medias_mim[29]="x-world/x-vrml";

// --- Fonctions ---

// retourne la balise OBJECT adaptee au navigateur utilise
function medias_baliseObject(id, url, auto, largeur, hauteur, console) {
  var obt;
  obt="<OBJECT ";
  // format IE
  if (medias_ie) {
    obt+="ID=\"" + id + "\" ";
    // ActiveX QuickTime
    if (typeMIME(url).indexOf("quicktime")!=-1) {
      obt+="CLASSID=\"clsid:02BF25D5-8C17-4B23-BC80-D3488ABDDC6B\" ";
      obt+="CODEBASE=\"http://www.apple.com/qtactivex/qtplugin.cab\" ";
    // ActiveX RealPlayer
    } else if (typeMIME(url).indexOf("realaudio")!=-1) {
      obt+="CLASSID=\"clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA\" ";
      obt+="CODEBASE=\"http://???\" ";
    // ActiveX Flash
    } else if (typeMIME(url).indexOf("shockwave")!=-1) {
      obt+="CLASSID=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" ";
      obt+="CODEBASE=\"http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0\" ";
    // ActiveX Windows MediaPlayer
    } else {
      obt+="CLASSID=\"clsid:22D6F312-B0F6-11D0-94AB-0080C74C7E95\" ";
      obt+="CODEBASE=\"http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=5,0,0,0\" ";
    }
    obt+="WIDTH=\"" + largeur + "\" HEIGHT=\"" + hauteur + "\" ALIGN=\"middle\">";
    // URL
    if (typeMIME(url).indexOf("shockwave")!=-1) {
        obt+="<PARAM NAME=\"MOVIE\" VALUE=\"" + url + "\">";
        obt+="<PARAM NAME=\"QUALITY\" VALUE=\"high\">";
    } else { obt+="<PARAM NAME=\"SRC\" VALUE=\"" + url + "\">"; }
  // format W3C
  } else {
    obt+="NAME=\"" + id + "\" DATA=\"" + url + "\" ";
    obt+="TYPE=\"" + typeMIME(url) + "\" ";
    obt+="WIDTH=\"" + largeur + "\" HEIGHT=\"" + hauteur + "\" ALIGN=\"middle\">";
  }
  // demarrage automatique
  if (auto) {
    obt+="<PARAM NAME=\"AUTOSTART\" VALUE=\"true\">";
    obt+="<PARAM NAME=\"AUTOPLAY\" VALUE=\"true\">";
  } else {
    obt+="<PARAM NAME=\"AUTOSTART\" VALUE=\"false\">";
    obt+="<PARAM NAME=\"AUTOPLAY\" VALUE=\"false\">";
  }
  // console
  obt+="<PARAM NAME=\"CONTROLLER\" VALUE=\"true\">";
  obt+="<PARAM NAME=\"CONSOLE\" VALUE=\"" + id + "\">";
  obt+="<PARAM NAME=\"CONTROLS\" VALUE=\"" + console + "\">";
  return(obt);
} // fin medias_baliseObject(id, url, auto, largeur, hauteur, console)

// insere un media audio
function insererAudio(id, url, auto, largeur, hauteur) {
  // traite les arguments manquants
  if ((!url) || (url=="")) { return false; }
  if (!auto) { auto=false; }
  if ((isNaN(largeur)) || (parseInt(largeur)<1)) { largeur=300; }
  if ((isNaN(hauteur)) || (parseInt(hauteur)<1)) { hauteur=45; }
  // balise OBJECT
  var txt;
  if (typeMIME(url).indexOf("realaudio")!=-1) {
    txt=medias_baliseObject(id, url, auto, largeur, hauteur, "ControlPanel");
  } else {
    txt=medias_baliseObject(id, url, auto, largeur, hauteur, "console");    
  }
  // balise EMBED
  txt+="<EMBED NAME=\"" + id + "\" SRC=\"" + url + "\" ";
  txt+="TYPE=\"" + typeMIME(url) + "\" MASTERSOUND ";
  // PLUGINSPAGE
  if (typeMIME(url).indexOf("quicktime")!=-1) {
    txt+="PLUGINSPAGE=\"http://www.apple.com/quicktime/download/\" ";  
  } else if (typeMIME(url).indexOf("realaudio")==-1) {
    txt+="PLUGINSPAGE=\"http://www.microsoft.com/isapi/redir.dll?prd=windows&sbp=mediaplayer&ar=Media&sba=Plugin\" ";
  }
  txt+="WIDTH=\"" + largeur + "\" HEIGHT=\"" + hauteur + "\" ";
  txt+="HIDDEN=\"false\" ALIGN=\"middle\" ";
  // demarrage automatique
  if (auto) { txt+="AUTOSTART=\"true\" AUTOPLAY=\"true\" "; }
  else { txt+="AUTOSTART=\"false\" AUTOPLAY=\"false\" "; }
  // console
  txt+="CONTROLLER=\"true\" CONSOLE=\"" + id + "\" ";  
  if (typeMIME(url).indexOf("realaudio")!=-1) {
    txt+="CONTROLS=\"ControlPanel\">";
  } else {
    txt+="CONTROLS=\"console\">";
  }
  txt+="</OBJECT>";
  return(txt);
} // fin insererAudio(id, url, auto, largeur, hauteur)

// insere une animation Flash
function insererFlash(id, url, largeur, hauteur) {
  // traite les arguments manquants
  if ((!url) || (url=="")) { return false; }
  if ((isNaN(largeur)) || (parseInt(largeur)<1)) { largeur=300; }
  if ((isNaN(hauteur)) || (parseInt(hauteur)<1)) { hauteur=225; }
  // balise OBJECT
  var txt;
  txt=medias_baliseObject(id, url, true, largeur, hauteur, "");
  // balise EMBED
  txt+="<EMBED NAME=\"" + id + "\" SRC=\"" + url + "\" QUALITY=\"high\" ";
  txt+="TYPE=\"" + typeMIME(url) + "\" ";
  txt+="PLUGINSPAGE=\"http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash\" ";
  txt+="WIDTH=\"" + largeur + "\" HEIGHT=\"" + hauteur + "\" ";
  txt+="HIDDEN=\"false\" ALIGN=\"middle\" ";
  txt+="AUTOSTART=\"true\" AUTOPLAY=\"true\" ";
  txt+="CONTROLLER=\"false\" CONSOLE=\"" + id + "\" CONTROLS=\"\">";
  txt+="</OBJECT>";
  return(txt);
} // fin insererFlash(id, url, largeur, hauteur)

// insere un media video
function insererVideo(id, url, auto, largeur, hauteur) {
  // traite les arguments manquants
  if ((!url) || (url=="")) { return false; }
  if (!auto) { auto=false; }
  if ((isNaN(largeur)) || (parseInt(largeur)<1)) { largeur=300; }
  if ((isNaN(hauteur)) || (parseInt(hauteur)<1)) { hauteur=270; }
  // balise OBJECT
  var txt;
  if (typeMIME(url).indexOf("realaudio")!=-1) {
    txt=medias_baliseObject(id, url, auto, largeur, hauteur, "ImageWindow,ControlPanel");
  } else {
    txt=medias_baliseObject(id, url, auto, largeur, hauteur, "console");    
  }
  // balise EMBED
  txt+="<EMBED NAME=\"" + id + "\" SRC=\"" + url + "\" ";
  txt+="TYPE=\"" + typeMIME(url) + "\" MASTERSOUND ";
  // PLUGINSPAGE
  if (typeMIME(url).indexOf("quicktime")!=-1) {
    txt+="PLUGINSPAGE=\"http://www.apple.com/quicktime/download/\" ";  
  } else if (typeMIME(url).indexOf("realaudio")==-1) {
    txt+="PLUGINSPAGE=\"http://www.microsoft.com/isapi/redir.dll?prd=windows&sbp=mediaplayer&ar=Media&sba=Plugin\" ";
  }
  txt+="WIDTH=\"" + largeur + "\" HEIGHT=\"" + hauteur + "\" ";
  txt+="HIDDEN=\"false\" ALIGN=\"middle\" ";
  // demarrage automatique
  if (auto) { txt+="AUTOSTART=\"true\" AUTOPLAY=\"true\" "; }
  else { txt+="AUTOSTART=\"false\" AUTOPLAY=\"false\" "; }
  // console
  txt+="CONTROLLER=\"true\" CONSOLE=\"" + id + "\" ";  
  if (typeMIME(url).indexOf("realaudio")!=-1) {
    txt+="CONTROLS=\"ImageWindow,ControlPanel\">";
  } else {
    txt+="CONTROLS=\"console\">";
  }
  txt+="</OBJECT>";
  return(txt);
} // fin insererVideo(id, url, auto, largeur, hauteur)

// retourne le type MIME du fichier d'URL specifiee
function typeMIME(url) {
  // traite les arguments manquants
  if ((!url) || (url=="")) { return ("inconnu"); }
  // cherche le type du fichier
  var xts;
  var tab;
  xts = (url.substring(url.lastIndexOf(".")+1)).toLowerCase();
  if (xts.indexOf(" ")!=-1)
    xts=xts.substring(0, xts.indexOf(" "));
  // parcoure le tableau des extensions
  for(var i=0; i<medias_ext.length; i++) {
    // parcoure le tableau des extensions du meme type
    tab=medias_ext[i].split(',');
    for(var j=0; j<tab.length; j++) {
      if (tab[j]==xts) return (medias_mim[i]);
    }
  }
  // retourne le type MIME par defaut
  return ("application/octet-stream");
} // fin typeMIME(url)
