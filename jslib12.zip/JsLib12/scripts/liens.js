/* liens.js
 * Role : insere dans la page Web un lien sur un texte, un bouton ou une image
 * Projet : JsLib
 * Auteur : Etienne CHEVILLARD (etienne@chevillard.org)
 * Version : 1.2
 * Creation : 30/04/2001
 * Mise a jour : 29/01/2003
 * Bogues connues : - Opera remplace les commentaires des liens par leurs URLs
 */

// ignore les erreurs
window.onerror=function () {
  return true;
}

// variables communes
var liens_cpt=0;

// --- Fonctions ---

// insere un lien vers une adresse e-mail sur un bouton
function lienBoutonEmail(texte, email, sujet, commentaire) {
  // traite les arguments manquants
  if (!email) { url="mailto:"; }
  if (! sujet) { sujet=""; }
  if (!commentaire) { commentaire=""; }
  // ecrit dans la page le code correspondant au lien
  var lcode="<FORM><INPUT TYPE=\"button\" VALUE=\""+texte+"\" onClick=\"window.location.href='mailto:";
  lcode+=email+"?subject="+sujet+"';\" onMouseOver=\"window.status='"+commentaire;
  lcode+="'; return true;\" onMouseOut=\"window.status=''; return true;\"></FORM>";
  return(lcode);
} // fin lienBoutonEmail(texte, email, sujet, commentaire)

// insere un lien vers une page Web sur un bouton
function lienBoutonWeb(texte, url, cible, commentaire) {
  var ldest;
  // traite les arguments manquants
  if (!url) { url="about:blank"; }
  if (!cible) { cible="_self"; }
  if (!commentaire) { commentaire=""; }
  // obtient la notation Javascript de la cible
  if (cible=="_self") { ldest="self.location.href='"+url+"'"; }
  else if (cible=="_parent") { ldest="parent.location.href='"+url+"'"; }
  else if (cible=="_top") { ldest="top.location.href='"+url+"'"; }
  else { ldest="window.open('"+url+"', '"+cible+"')"; }
  // ecrit dans la page le code correspondant au lien
  var lcode="<FORM><INPUT TYPE=\"button\" VALUE=\""+texte+"\" onClick=\""+ldest;
  lcode+=";\" onMouseOver=\"window.status='"+commentaire;
  lcode+="'; return true;\" onMouseOut=\"window.status=''; return true;\"></FORM>";
  return(lcode);
} // fin lienBoutonWeb(texte, url, cible, commentaire)

// insere un lien vers vers une adresse e-mail sur une image dynamique
function lienDynaEmail(image_out, image_over, email, sujet, commentaire) {
  // traite les arguments manquants
  if (!email) { url="mailto:"; }
  if (! sujet) { sujet=""; }
  if (!commentaire) { commentaire=""; }
  // ecrit dans la page le code correspondant au lien
  var lcode="<A HREF=\"mailto:"+email+"?subject="+sujet+"\" onMouseOver=\"liens_image"+liens_cpt;
  lcode+=".src='"+image_over+"'; window.status='"+commentaire+"'; return true;\" ";
  lcode+=" onMouseOut=\"liens_image"+liens_cpt+".src='"+image_out+"'; window.status=''; return true;\">";
  lcode+="<IMG NAME=\"liens_image"+liens_cpt+"\" SRC=\""+image_out+"\" BORDER=0 ALIGN=MIDDLE ";
  lcode+="onLoad=\"liens_image_temp=new Image(0,0); liens_image_temp.src='"+image_over+"'; return true;\"></A>";
  // incremente le compteur d'images
  liens_cpt=parseInt(liens_cpt)+1;
  return (lcode);
} // fin lienDynaEmail(image_out, image_over, email, sujet, commentaire)

// insere un lien vers une page Web sur une image dynamique
function lienDynaWeb(image_out, image_over, url, cible, commentaire) {
  // traite les arguments manquants
  if (!url) { url="about:blank"; }
  if (!cible) { cible="_self"; }
  if (!commentaire) { commentaire=""; }
  // ecrit dans la page le code correspondant au lien
  var lcode="<A HREF=\""+url+"\" TARGET=\""+cible+"\" onMouseOver=\"liens_image"+liens_cpt;
  lcode+=".src='"+image_over+"'; window.status='"+commentaire+"'; return true;\" ";
  lcode+=" onMouseOut=\"liens_image"+liens_cpt+".src='"+image_out+"'; window.status=''; return true;\">";
  lcode+="<IMG NAME=\"liens_image"+liens_cpt+"\" SRC=\""+image_out+"\" BORDER=0 ALIGN=MIDDLE ";
  lcode+="onLoad=\"liens_image_temp=new Image(0,0); liens_image_temp.src='"+image_over+"'; return true;\"></A>";
  // incremente le compteur d'images
  liens_cpt=parseInt(liens_cpt)+1;
  return(lcode);
} // fin lienDynaWeb(image_out, image_over, url, cible, commentaire)

// insere un lien vers une adresse e-mail sur une image
function lienImageEmail(image, email, sujet, commentaire) {
  // traite les arguments manquants
  if (!email) { url="mailto:"; }
  if (! sujet) { sujet=""; }
  if (!commentaire) { commentaire=""; }
  // ecrit dans la page le code correspondant au lien
  var lcode="<A HREF=\"mailto:"+email+"?subject="+sujet+"\" onMouseOver=\"window.status='"+commentaire;
  lcode+="'; return true;\" onMouseOut=\"window.status=''; return true;\">";
  lcode+="<IMG SRC=\""+image+"\" BORDER=0 ALIGN=MIDDLE ALT=\""+commentaire+"\"></A>";
  return(lcode);
} // fin lienImageEmail(image, email, sujet, commentaire)

// insere un lien vers une page Web sur une image
function lienImageWeb(image, url, cible, commentaire) {
  // traite les arguments manquants
  if (!url) { url="about:blank"; }
  if (!cible) { cible="_self"; }
  if (!commentaire) { commentaire=""; }
  // ecrit dans la page le code correspondant au lien
  var lcode="<A HREF=\""+url+"\" TARGET=\""+cible+"\" onMouseOver=\"window.status='"+commentaire;
  lcode+="'; return true;\" onMouseOut=\"window.status=''; return true;\">";
  lcode+="<IMG SRC=\""+image+"\" BORDER=0 ALIGN=MIDDLE ALT=\""+commentaire+"\"></A>";
  return(lcode);
} // fin lienImageWeb(image, url, cible, commentaire)

// insere un lien vers une adresse e-mail sur un texte
function lienTexteEmail(texte, email, sujet, commentaire) {
  // traite les arguments manquants
  if (!email) { url="mailto:"; }
  if (! sujet) { sujet=""; }
  if (!commentaire) { commentaire=""; }
  // ecrit dans la page le code correspondant au lien
  var lcode="<A HREF=\"mailto:"+email+"?subject="+sujet+"\" onMouseOver=\"window.status='"+commentaire;
  lcode+="'; return true;\" onMouseOut=\"window.status=''; return true;\">"+texte+"</A>";
  return(lcode);
} // fin lienTexteEmail(texte, email, sujet, commentaire)

// insere un lien vers une page Web sur un texte
function lienTexteWeb(texte, url, cible, commentaire) {
  // traite les arguments manquants
  if (!url) { url="about:blank"; }
  if (!cible) { cible="_self"; }
  if (!commentaire) { commentaire=""; }
  // ecrit dans la page le code correspondant au lien
  var lcode="<A HREF=\""+url+"\" TARGET=\""+cible+"\" onMouseOver=\"window.status='"+commentaire;
  lcode+="'; return true;\" onMouseOut=\"window.status=''; return true;\">"+texte+"</A>";
  return(lcode);
} // fin lienTexteWeb(texte, url, cible, commentaire)
