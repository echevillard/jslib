/* date.js
 * Role : formate la date du jour et la date de modification du document
 * Projet : JsLib
 * Auteur : Etienne CHEVILLARD (etienne@chevillard.org)
 * Version : 1.2
 * Creation : 22/04/2001
 * Mise a jour : 29/01/2003
 */

// ignore les erreurs
window.onerror=function () {
  return true;
}

// definit un tableau pour les jours de la semaine
var date_jours=new Array(7);
date_jours[0]="Dimanche";
date_jours[1]="Lundi";
date_jours[2]="Mardi";
date_jours[3]="Mercredi";
date_jours[4]="Jeudi";
date_jours[5]="Vendredi";
date_jours[6]="Samedi";
// definit un tableau pour les mois de l'annee
var date_mois=new Array(12);
date_mois[0]="janvier";
date_mois[1]="f&eacute;vrier";
date_mois[2]="mars";
date_mois[3]="avril";
date_mois[4]="mai";
date_mois[5]="juin";
date_mois[6]="juillet";
date_mois[7]="ao&ucirc;t";
date_mois[8]="septembre";
date_mois[9]="octobre";
date_mois[10]="novembre";
date_mois[11]="d&eacute;cembre";
// obtient la date de derniere modification du document
var date_der=new Date(document.lastModified);
// corrige une bogue de Netscape 4 (annee sur deux chiffres)
if ((date_der.getFullYear()+50)<(new Date()).getFullYear()) {
  date_der.setFullYear(parseInt(date_der.getFullYear())+100);
}

// --- Fonctions ---

// retourne la date du jour au format JJ mmm AAAA
function dateJour() {
  // obtient la date du jour
  var dcour=new Date();
  // rajoute "er" au jour si c'est le premier du mois
  var dj=dcour.getDate();
  if (dj=="1") dj="1er";
  // obtient le mois en toutes lettres
  var dm=dcour.getMonth();
  dm=date_mois[parseInt(dm)];
  // retourne la date formatee
  return (dj+" "+dm+" "+dcour.getFullYear());
} // fin dateJour()

// retourne la date du jour en abrege, au format JJ/MM/AAAA
function dateJourAbr() {
  // obtient la date du jour
  var dcour=new Date();
  // obtient le mois sur deux caracteres
  var dm=parseInt(dcour.getMonth())+1;
  if (dm<10) dm="0"+dm;
  // retourne la date formatee
  return (dcour.getDate()+"/"+dm+"/"+dcour.getFullYear());
} // fin dateJourAbr()

// retourne la date du jour au format Jjj JJ mmm AAAA
function dateJourLng() {
  // obtient la date du jour
  var dcour=new Date();
  // rajoute "er" au jour si c'est le premier du mois
  var dj=dcour.getDate();
  if (dj=="1") dj="1er";
  // obtient le mois en toutes lettres
  var dm=dcour.getMonth();
  dm=date_mois[parseInt(dm)];
  // obtient le jour de la semaine en toutes lettres
  var dd=dcour.getDay();
  dd=date_jours[parseInt(dd)];
  // retourne la date formatee
  return (dd+" "+dj+" "+dm+" "+dcour.getFullYear());
} // fin dateJourLng()

// retourne la date de derniere modification du document au format JJ mmm AAAA
function dateModif() {
  // rajoute "er" au jour si c'est le premier du mois
  var dj=date_der.getDate();
  if (dj=="1") dj="1er";
  // obtient le mois en toutes lettres
  var dm=date_der.getMonth();
  dm=date_mois[parseInt(dm)];
  // retourne la date formatee
  return (dj+" "+dm+" "+date_der.getFullYear());
} // fin dateModif()

// retourne la date de derniere modification du document au format JJ/MM/AAAA
function dateModifAbr() {
  // obtient le mois sur deux caracteres
  var dm=parseInt(date_der.getMonth())+1;
  if (dm<10) dm="0"+dm;
  // retourne la date formatee
  return (date_der.getDate()+"/"+dm+"/"+date_der.getFullYear());
} // fin dateModifAbr()

// retourne la date de derniere modification du document au format Jjj JJ mmm AAAA
function dateModifLng() {
  // obtient le jour de la semaine en toutes lettres
  var dd=date_der.getDay();
  dd=date_jours[parseInt(dd)];
  // retourne la date formatee
  return (dd+" "+dateModif());
} // fin dateModifLng()
