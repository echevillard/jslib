/* cookies.js
 * Role : lit, ecrit et efface les cookies de la page Web courante
 * Projet : JsLib
 * Auteur : Etienne CHEVILLARD (etienne@chevillard.org)
 * Version : 1.2
 * Creation : 11/04/2001
 * Mise a jour : 29/01/2003
 */

// ignore les erreurs
window.onerror=function () {
  return true;
}

// verifie que le navigateur accepte les cookies
var cookies_ok=false;
if (navigator.cookieEnabled) {
  cookies_ok=true;
} else {
  ecrireCookie ("jslib", "ok");
  if (lireCookie("jslib")=="ok") cookies_ok=true;
  effacerCookie("jslib");
}

// --- Fonctions ---

// indique si le navigateur accepte les cookies
function accepteCookies() {
  return (cookies_ok);
} // fin accepteCookies()

// ecrit un cookie de nom et valeur specifiees pour le nombre de jours specifie
function ecrireCookie(nom, valeur, jours) {
  if (!cookies_ok) return false;
  if (!nom || nom=="") return false;
  if (!valeur) { valeur=""; }
  if (!jours) { jours=0; }
  var expire;
  // expiration au bout d'un certain nombre de jours
  if (parseInt(jours)!=0) {
    var date=new Date();
    date.setTime(date.getTime()+(parseInt(jours)*24*60*60*1000));
    expire="; expires="+date.toGMTString();
  // expiration a l'arret du navigateur
  } else { expire=""; }
  // ecrit le cookie
  document.cookie=nom+"="+escape(valeur)+expire+"; path=/";
  return true;
} // fin ecrireCookie(nom, valeur, jours)

// efface le cookie de nom specifie
function effacerCookie(nom) {
  // re-ecrit le cookie avec une date d'expiration negative
  return (ecrireCookie(nom, "", -1));
} // fin effacerCookie(nom)

// lit et retourne la valeur du cookie de nom specifie
function lireCookie(nom) {
  if (!cookies_ok) return ("");
  if (!nom || nom=="") return ("");
  // nom complet du cookie
  var nomEq=nom+"=";
  // cree un tableau pour les cookies du document
  var tab=document.cookie.split(";");
  // parcoure le tableau et cherche le cookie
  for(var i=0; i<tab.length; i++) {
    var cook=tab[i];
    while (cook.charAt(0)==' ')
      cook=cook.substring(1, cook.length);
    if (cook.indexOf(nomEq)==0)
      return unescape(cook.substring(nomEq.length, cook.length));
  }
  // si pas de correspondance, retourne une chaine vide
  return ("");
} // fin lireCookie(nom)
