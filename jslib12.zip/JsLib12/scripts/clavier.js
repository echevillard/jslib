/* clavier.js
 * Role : capture et gere les evenements clavier
 * Projet : JsLib
 * Auteur : Etienne CHEVILLARD (etienne@chevillard.org)
 * Version : 1.2
 * Creation : 28/07/2001
 * Mise a jour : 29/01/2003
 * Bogues connues : - Netscape Navigator 4 et Opera ignorent certaines touches de fonction
 */

// ignore les erreurs
window.onerror=function () {
  return true;
}

// corrige le code des touches
var clavier_un=-1;
var clavier_deux=-1;

// capture les evenements sous Netscape Navigator
if (document.layers) {
  document.captureEvents(Event.KEYDOWN);
  document.captureEvents(Event.KEYPRESS);
  document.captureEvents(Event.KEYUP);
}

// correspondance code/role pour les touches de fonction
var clavier_cds=new Array(146);
clavier_cds[8]="Retour arriere";
clavier_cds[9]="Tabulation";
clavier_cds[12]="Milieu (pave numerique)";
clavier_cds[13]="Entree";
clavier_cds[16]="Shift";
clavier_cds[17]="Ctrl";
clavier_cds[18]="Alt";
clavier_cds[19]="Pause";
clavier_cds[20]="Verr Maj";
clavier_cds[27]="Echap";
clavier_cds[32]="Espace";
clavier_cds[33]="Page precedente";
clavier_cds[34]="Page suivante";
clavier_cds[35]="Fin";
clavier_cds[36]="Debut";
clavier_cds[37]="Fleche gauche";
clavier_cds[38]="Fleche haut";
clavier_cds[39]="Fleche droite";
clavier_cds[40]="Fleche bas";
clavier_cds[44]="Impr ecran";
clavier_cds[45]="Inser";
clavier_cds[46]="Suppr";
clavier_cds[91]="Menu Demarrer Windows";
clavier_cds[92]="Menu Demarrer Windows";
clavier_cds[93]="Menu contextuel Windows";
clavier_cds[112]="F1";
clavier_cds[113]="F2";
clavier_cds[114]="F3";
clavier_cds[115]="F4";
clavier_cds[116]="F5";
clavier_cds[117]="F6";
clavier_cds[118]="F7";
clavier_cds[119]="F8";
clavier_cds[120]="F9";
clavier_cds[121]="F10";
clavier_cds[122]="F11";
clavier_cds[123]="F12";
clavier_cds[144]="Verr Num";
clavier_cds[145]="Arret defil";

// correction pour les touches de fonction sous Opera
var clavier_cor=new Array(103);
clavier_cor[45]=112;
clavier_cor[46]=113;
clavier_cor[47]=114;
clavier_cor[48]=115;
clavier_cor[49]=116;
clavier_cor[50]=117;
clavier_cor[51]=118;
clavier_cor[52]=119;
clavier_cor[53]=120;
clavier_cor[54]=121;
clavier_cor[55]=122;
clavier_cor[56]=123;
clavier_cor[69]=36;
clavier_cor[70]=35;
clavier_cor[71]=33;
clavier_cor[72]=34;
clavier_cor[73]=38;
clavier_cor[74]=40;
clavier_cor[75]=37;
clavier_cor[76]=39;
clavier_cor[78]=47;
clavier_cor[79]=42;
clavier_cor[80]=43;
clavier_cor[81]=45;
clavier_cor[82]=45;
clavier_cor[83]=46;
clavier_cor[88]=18;
clavier_cor[89]=16;
clavier_cor[90]=17;
clavier_cor[100]=144;
clavier_cor[101]=145;
clavier_cor[102]=19;

// --- Fonctions ---

// retourne le code clavier de la derniere touche enfoncee ou relachee
function codeTouche(e) {
  var cret;
  if (window.event) {
    if (parseInt(clavier_deux)>0) cret=clavier_deux;
    else cret=window.event.keyCode;
    if (window.event.type=="keypress") clavier_deux=window.event.keyCode;
    if (window.event.type=="keydown") clavier_deux=-1;
  } else {
    if (parseInt(clavier_deux)>0) cret=clavier_deux;
    else if ((parseInt(clavier_un)>0) && (e.which<1)) cret=clavier_un;
    else cret=e.which;
    if (e.type=="keydown") {
      clavier_un=e.which;
      clavier_deux=-1;
    }
    if (e.type=="keypress") clavier_deux=e.which;
  }
  if (parseInt(cret)>57000) {
    cret = clavier_cor[cret-57300];
    clavier_deux=-1;
  }
  return (parseInt(cret));
} // fin codeTouche(e)

// retourne le caractere ou la fonction correspondant a la derniere touche enfoncee ou relachee
function correspTouche(e) {
  var ccod=codeTouche(e);
  if (toucheCtrl(e) && toucheAlt(e)) return "Alt Gr";
  if (parseInt(ccod)==8) return clavier_cds[ccod];
  if (parseInt(ccod)==9) return clavier_cds[ccod];
  if (parseInt(ccod)==13) return clavier_cds[ccod];
  if (parseInt(ccod)==27) return clavier_cds[ccod];
  if (parseInt(ccod)==32) return clavier_cds[ccod];
  if ((clavier_cds[ccod]) && (parseInt(clavier_deux)<1)) {
    return (clavier_cds[ccod]);
  } else {
    return (String.fromCharCode(ccod));
  }
} // fin correspTouche(e)

// retourne vrai si la touche Alt a ete enfoncee avec la derniere touche enfoncee ou relachee
function toucheAlt(e) {
  if (window.event) {
    return (window.event.altKey);
  } else {
    return (e.altKey || (e.modifiers % 2));
  }
} // fin toucheAlt(e)

// retourne vrai si la touche Ctrl a ete enfoncee avec la derniere touche enfoncee ou relachee
function toucheCtrl(e) {
  if (window.event) {
    return (window.event.ctrlKey);
  } else {
    return (e.ctrlKey || (e.modifiers==2) || (e.modifiers==3) || (e.modifiers>5));
  }
} // fin toucheCtrl(e)

// retourne vrai si la touche Shift a ete enfoncee avec la derniere touche enfoncee ou relachee
function toucheShift(e) {
  if (window.event) {
    return (window.event.shiftKey);
  } else {
    return (e.shiftKey || (e.modifiers>3));
  }
} // fin toucheShift(e)
